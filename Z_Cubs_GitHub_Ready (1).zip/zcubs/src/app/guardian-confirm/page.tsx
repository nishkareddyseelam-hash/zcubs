import * as consent from "@/lib/consent";
import { Card } from "@/components/ui";

/** Public confirmation page for a guardian relationship (D-010) — no login
 * required, since the guardian is very unlikely to have a Z Cubs account.
 * Confirming here is what "guardian consent" means in this build: whoever
 * holds this link clicked it. That is a real, honest bar, not identity
 * verification — stated plainly rather than implied to be more. */
export default async function GuardianConfirmPage({
  searchParams,
}: {
  searchParams: { rel?: string; token?: string };
}) {
  const rel = searchParams.rel;
  const token = searchParams.token;

  if (!rel || !token) {
    return (
      <div style={{ maxWidth: 560, margin: "48px auto", padding: "0 16px" }}>
        <Card>
          <h2 className="font-display text-[20px]">Missing confirmation details</h2>
          <p style={{ marginTop: 8, color: "var(--text-dim)" }}>This link is incomplete. Ask the founder to resend it from their Privacy &amp; Consent page.</p>
        </Card>
      </div>
    );
  }

  let outcome: { ok: true; name: string } | { ok: false; message: string };
  try {
    const confirmed = await consent.confirmGuardianRelationship(rel, token);
    outcome = { ok: true, name: confirmed.explorerUserId };
  } catch (err) {
    outcome = { ok: false, message: err instanceof Error ? err.message : "Could not confirm this relationship." };
  }

  return (
    <div style={{ maxWidth: 560, margin: "48px auto", padding: "0 16px" }}>
      <div className="eyebrow">Z Cubs</div>
      <h2 className="font-display text-[24px] mt-1">Guardian confirmation</h2>
      <Card className="mt-4">
        {outcome.ok ? (
          <>
            <p style={{ color: "var(--good)" }}>Confirmed.</p>
            <p style={{ marginTop: 8, color: "var(--text-dim)" }}>
              You&apos;ve confirmed this guardian relationship on Z Cubs. You can revoke it at any time by asking
              the account holder to remove it from their Privacy &amp; Consent page, or by contacting Z Cubs support.
            </p>
          </>
        ) : (
          <p style={{ color: "var(--gap)" }}>{outcome.message}</p>
        )}
      </Card>
    </div>
  );
}
