import type { Metadata, Viewport } from "next";
import "./globals.css";
import Providers from "@/components/Providers";

// Fonts are loaded via <link> at runtime (not next/font/google) so the
// production build does not require outbound network access to Google
// Fonts. The browser fetches them normally when the app is served.

export const metadata: Metadata = {
  title: "Z Cubs — Founder Operating System",
  description: "India's evidence-led Founder Operating System for Gen Z and Gen Alpha.",
};

// Explicit viewport (fix: previously relied entirely on Next's implicit
// default, which does not set viewport-fit=cover — the fixed-position
// mentor button/drawer in Shell.tsx can sit under a device's safe-area
// inset (notch/home-indicator) without it).
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Sora:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
