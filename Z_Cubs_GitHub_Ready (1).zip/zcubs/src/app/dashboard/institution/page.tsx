import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import * as inst from "@/lib/institutional";
import * as mentorship from "@/lib/mentorship";
import * as facilitators from "@/lib/facilitators";
import { hasRole } from "@/lib/institutional";
import {
  createInstitutionAction, createProgrammeAction, updateProgrammeStatusAction, createCohortAction,
  submitApplicationAction, assignEvaluatorAction, submitEvaluationAction, selectAndEnrolAction, recordSelectionDecisionAction,
  addEvaluationCriterionAction, removeEvaluationCriterionAction,
  updateCohortMembershipStatusAction, transferCohortMembershipAction,
  grantFacilitatorRoleAction, acknowledgeWeekReadinessAction, logFacilitatedSessionAction,
} from "@/lib/actions";
import { Card, Notice } from "@/components/ui";

/** Institution / Programme / Cohort dashboard — the vertical slice from
 * docs/DECISION_LOG.md D-006: an institution creates a programme (which
 * auto-seeds the configurable 14-week journey and a minimal application
 * form) → a founder applies → a programme manager assigns an evaluator →
 * the evaluator scores it → the programme manager selects and enrols the
 * founder into a cohort. Every list here is scoped to institutions this
 * user actually belongs to (RoleAssignment-checked on every write) — see
 * src/lib/institutional.ts for the enforcement. */
export default async function InstitutionPage() {
  const userId = await requireUserId();
  const myInstitutions = await inst.listMyInstitutions(userId);
  const myInstitutionIds = new Set(myInstitutions.map((i) => i.id));
  const openProgrammes = (await inst.listOpenPublicProgrammes()).filter((p) => !myInstitutionIds.has(p.institutionId));

  return (
    <div>
      <div className="eyebrow">Institutional Edition</div>
      <h2 className="font-display text-[26px] mt-1">Institutions, programmes & cohorts</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        Create an institution, build a programme (this seeds the configurable 14-week journey and a starter application form),
        open a cohort, and take an application from submission through evaluation to selection — the one fully connected
        institutional workflow in this release. Everything else in the full spec is tracked in <code>docs/ROADMAP.md</code> as Planned.
      </p>

      {myInstitutions.length === 0 && (
        <Notice tone="default">You don&apos;t belong to any institution yet. Create one below, or apply to an open programme below.</Notice>
      )}

      {openProgrammes.length > 0 && (
        <Card className="mt-5">
          <h4 className="font-display text-[18px]">Open programmes you can apply to</h4>
          <p style={{ color: "var(--text-faint)", fontSize: 14 }}>Public programmes with applications currently open — no institutional membership required to apply.</p>
          <div className="flex flex-col gap-3 mt-3">
            {await Promise.all(openProgrammes.map(async (programme) => {
              const form = await inst.getApplicationForm(programme.id);
              if (!form) return null;
              return (
                <div key={programme.id} className="card pad">
                  <b>{programme.title}</b> <span style={{ color: "var(--text-faint)", fontSize: 13 }}>— {programme.institutionName}</span>
                  <form action={submitApplicationAction.bind(null, form.id)} className="flex flex-col gap-2 mt-2" style={{ maxWidth: 480 }}>
                    {form.questions.map((question) => (
                      <label key={question.id} style={{ fontSize: 13 }}>
                        {question.label}
                        {question.fieldType === "declaration" ? (
                          <div><input type="checkbox" name={`q_${question.id}`} value="yes" required={question.required} /> I agree</div>
                        ) : (
                          <textarea name={`q_${question.id}`} required={question.required} className="field-input" style={{ width: "100%" }} />
                        )}
                      </label>
                    ))}
                    <button type="submit" className="btn btn-primary btn-sm">Submit application</button>
                  </form>
                </div>
              );
            }))}
          </div>
        </Card>
      )}

      <div className="grid gap-4 mt-5">
        {myInstitutions.map((institution) => (
          <InstitutionCard key={institution.id} institution={institution} userId={userId} />
        ))}
      </div>

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Register a new institution</h4>
        <p style={{ color: "var(--text-faint)", fontSize: 14 }}>
          Status starts as <b>Draft</b>. No institution is ever labelled &quot;government approved&quot; or &quot;IIC compliant&quot; without a
          verified record — see the Institutional Reporting guide.
        </p>
        <form action={createInstitutionAction} className="flex gap-2 mt-3 flex-wrap">
          <input name="name" required className="field-input" placeholder="Institution name" style={{ maxWidth: 280 }} />
          <select name="institutionType" className="field-input" style={{ maxWidth: 200 }}>
            <option value="university">University</option>
            <option value="school">School</option>
            <option value="incubator">Incubator</option>
            <option value="accelerator">Accelerator</option>
            <option value="government_programme">Government programme</option>
          </select>
          <input name="state" className="field-input" placeholder="State" style={{ maxWidth: 160 }} />
          <input name="contactEmail" type="email" className="field-input" placeholder="Contact email" style={{ maxWidth: 220 }} />
          <button type="submit" className="btn btn-primary">Create institution</button>
        </form>
      </Card>
    </div>
  );
}

async function InstitutionCard({ institution, userId }: { institution: inst.Institution; userId: string }) {
  const programmes = await inst.listProgrammes(institution.id);
  return (
    <Card>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h4 className="font-display text-[18px]">{institution.name}</h4>
        <span className="badge badge-grey">{institution.status.replace(/_/g, " ")}</span>
      </div>
      <p style={{ color: "var(--text-faint)", fontSize: 14 }}>{institution.institutionType.replace(/_/g, " ")}{institution.state ? ` · ${institution.state}` : ""}</p>

      <div className="mt-4 flex flex-col gap-3">
        {programmes.map((programme) => (
          <ProgrammeRow key={programme.id} programme={programme} userId={userId} />
        ))}
      </div>

      <FacilitatorAdmin institution={institution} />

      <details className="mt-4">
        <summary style={{ cursor: "pointer", fontSize: 15, color: "var(--accent)" }}>+ Create a programme</summary>
        <form action={createProgrammeAction.bind(null, institution.id)} className="flex gap-2 mt-3 flex-wrap">
          <input name="title" required className="field-input" placeholder="Programme title" style={{ maxWidth: 280 }} />
          <select name="programmeType" className="field-input" style={{ maxWidth: 220 }}>
            <option value="university_pre_incubation">University pre-incubation</option>
            <option value="school_innovation">School innovation programme</option>
            <option value="ideathon">Ideathon</option>
            <option value="hackathon">Hackathon</option>
            <option value="pre_accelerator">Pre-accelerator</option>
            <option value="incubator_intake">Incubator intake</option>
            <option value="government_youth">Government youth entrepreneurship</option>
            <option value="women_entrepreneurship">Women entrepreneurship</option>
            <option value="social_impact">Social-impact programme</option>
            <option value="rural_entrepreneurship">Rural entrepreneurship</option>
          </select>
          <select name="ageGroup" className="field-input" style={{ maxWidth: 140 }}>
            <option value="18+">18+</option>
            <option value="13-17">13–17 (Explorer)</option>
          </select>
          <select name="visibility" className="field-input" style={{ maxWidth: 200 }}>
            <option value="institution_only">Institution-only (default)</option>
            <option value="public">Public — any founder can apply</option>
            <option value="invite_only">Invite-only</option>
          </select>
          <textarea name="description" className="field-input" placeholder="Short description" style={{ width: "100%", minHeight: 60 }} />
          <button type="submit" className="btn btn-primary btn-sm">Create programme</button>
        </form>
      </details>
    </Card>
  );
}

/** D-022 (docs/DECISION_LOG.md): faculty-enablement / train-the-trainer
 * track — Wadhwani's real scale mechanism is training an institution's own
 * staff to run sessions themselves, instead of routing every founder
 * through a scarce pool of outside 1:1 mentors. Staff (owner/administrator/
 * programme manager) designate an existing institution member as a
 * `cohort_facilitator`; that role then unlocks the per-programme readiness
 * checklist and session logging below. */
async function FacilitatorAdmin({ institution }: { institution: inst.Institution }) {
  const [current, members] = await Promise.all([
    facilitators.listFacilitators(institution.id),
    facilitators.listInstitutionMembersWithNames(institution.id),
  ]);
  const facilitatorIds = new Set(current.map((f) => f.userId));
  const candidates = members.filter((m) => !facilitatorIds.has(m.userId));
  return (
    <details className="mt-4">
      <summary style={{ cursor: "pointer", fontSize: 15, color: "var(--accent)" }}>
        + Facilitators — {current.length} of your own staff enabled to run sessions
      </summary>
      <p style={{ color: "var(--text-faint)", fontSize: 13, maxWidth: "60ch" }}>
        A facilitator is one of this institution&apos;s own staff, trained on the seeded weekly guidance, who can run a
        cohort&apos;s session themselves — the alternative to relying only on outside mentor accounts (docs/ROADMAP.md).
      </p>
      {current.length > 0 && (
        <ul className="mt-2 flex flex-col gap-1" style={{ fontSize: 13 }}>
          {current.map((f) => (
            <li key={f.userId}>{f.userName} <span style={{ color: "var(--text-faint)" }}>({f.userEmail})</span></li>
          ))}
        </ul>
      )}
      {candidates.length > 0 ? (
        <form action={grantFacilitatorRoleAction.bind(null, institution.id)} className="flex gap-2 mt-3 items-center flex-wrap">
          <select name="userId" required className="field-input" style={{ fontSize: 13, maxWidth: 260 }}>
            <option value="">Choose a member…</option>
            {candidates.map((m) => <option key={m.userId} value={m.userId}>{m.userName} ({m.userEmail})</option>)}
          </select>
          <button type="submit" className="btn btn-ghost btn-sm">Make facilitator</button>
        </form>
      ) : (
        members.length === 0 && (
          <p style={{ color: "var(--text-faint)", fontSize: 13, marginTop: 6 }}>
            Nobody has joined this institution as a member yet — a facilitator has to be an existing member first.
          </p>
        )
      )}
    </details>
  );
}

/** The real "training materials" step: a facilitator reads this
 * programme's actual seeded facultyGuidance/mentorPrompt/youthSafetyNote
 * per week (the same text institutions already had — see
 * DEFAULT_14_WEEK_TEMPLATE, src/lib/institutional.ts) and acknowledges it
 * before they're allowed to log a session for that week. */
async function FacilitatorReadiness({ programme, userId }: { programme: inst.Programme; userId: string }) {
  const isFacilitator = await hasRole(userId, "cohort_facilitator", "programme", programme.id);
  if (!isFacilitator) return null;
  const weeks = await inst.listProgrammeWeeks(programme.id);
  const ready = await facilitators.getWeekReadiness(programme.id, userId);
  return (
    <details className="mt-3" style={{ borderTop: "1px solid var(--border, #2a2a2a)", paddingTop: 8 }}>
      <summary style={{ cursor: "pointer", fontSize: 13, color: "var(--accent)" }}>
        Your facilitator readiness — {ready.size}/{weeks.length} weeks acknowledged
      </summary>
      <ul className="mt-2 flex flex-col gap-2" style={{ fontSize: 12 }}>
        {weeks.map((w) => (
          <li key={w.id} className="card pad" style={{ padding: 8 }}>
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <b>Week {w.weekNumber}: {w.title}</b>
              {ready.has(w.weekNumber) ? (
                <span className="badge badge-grey" style={{ fontSize: 10 }}>Acknowledged</span>
              ) : (
                <form action={async () => { "use server"; await acknowledgeWeekReadinessAction(programme.id, w.weekNumber); }}>
                  <button type="submit" className="btn btn-ghost btn-sm" style={{ fontSize: 11, padding: "1px 6px" }}>I&apos;ve read this — mark ready</button>
                </form>
              )}
            </div>
            <p style={{ color: "var(--text-faint)", marginTop: 4 }}><b>Faculty guidance:</b> {w.facultyGuidance || "—"}</p>
            {w.youthSafetyNote && <p style={{ color: "var(--gap, #b3413a)", marginTop: 2 }}><b>Youth safety:</b> {w.youthSafetyNote}</p>}
          </li>
        ))}
      </ul>
    </details>
  );
}

/** Log that this cohort's own trained staff ran a week's session
 * themselves — server-side blocked (facilitators.ts) until that week's
 * readiness has been acknowledged. */
async function FacilitatedSessionLog({ cohort, userId, weeks }: { cohort: inst.Cohort; userId: string; weeks: inst.ProgrammeWeek[] }) {
  const isFacilitator = await hasRole(userId, "cohort_facilitator", "cohort", cohort.id);
  const sessions = await facilitators.listFacilitatedSessions(cohort.id);
  if (!isFacilitator && sessions.length === 0) return null;
  return (
    <div style={{ fontSize: 12, marginTop: 2, marginLeft: 2 }}>
      {isFacilitator && (
        <form action={async (fd: FormData) => { "use server"; await logFacilitatedSessionAction(cohort.id, Number(fd.get("weekNumber")), fd); }}
          className="flex gap-1 items-center flex-wrap mt-1">
          <select name="weekNumber" required className="field-input" style={{ fontSize: 11, padding: "1px 4px" }}>
            <option value="">Log a session for week…</option>
            {weeks.map((w) => <option key={w.weekNumber} value={w.weekNumber}>Week {w.weekNumber}</option>)}
          </select>
          <input name="summary" required placeholder="What the session covered" className="field-input" style={{ fontSize: 11, padding: "1px 4px", width: 180 }} />
          <input name="foundersPresent" type="number" min={0} placeholder="# present" className="field-input" style={{ fontSize: 11, padding: "1px 4px", width: 70 }} />
          <button type="submit" className="btn btn-ghost btn-sm" style={{ fontSize: 11, padding: "1px 6px" }}>Log</button>
        </form>
      )}
      {sessions.length > 0 && (
        <details style={{ marginTop: 2 }}>
          <summary style={{ cursor: "pointer", color: "var(--accent)" }}>{sessions.length} internal session{sessions.length === 1 ? "" : "s"} logged</summary>
          <ul className="mt-1 flex flex-col gap-1">
            {sessions.map((s) => (
              <li key={s.id} style={{ color: "var(--text-faint)" }}>
                Week {s.weekNumber} — {s.summary} ({s.foundersPresent} founder{s.foundersPresent === 1 ? "" : "s"} present)
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
  );
}

/** Honest coverage aggregate, additive to MentorCoverageLine — of this
 * programme's real seeded weeks, how many has this cohort's own staff
 * actually run themselves. */
async function FacilitatorCoverageLine({ cohortId }: { cohortId: string }) {
  const coverage = await facilitators.computeFacilitatorCoverageForCohort(cohortId);
  if (coverage.weeksTotal === 0) return null;
  return (
    <div style={{ fontSize: 12, color: "var(--text-faint)", marginTop: 2, marginLeft: 2 }}>
      Internal facilitation: {coverage.weeksWithInternalSession}/{coverage.weeksTotal} weeks run by your own staff ·{" "}
      {coverage.totalSessionsLogged} session{coverage.totalSessionsLogged === 1 ? "" : "s"} logged
    </div>
  );
}

/** YUKTI/IIC-style institutional reporting layer (D-009, docs/DECISION_LOG.md)
 * — a live, honest aggregate of real Mentor Discovery & Matching activity
 * for this cohort's own founders. Every figure is a live COUNT, never a
 * fabricated "readiness" score, and this never feeds or claims any
 * connection to a government ranking. */
async function MentorCoverageLine({ cohortId }: { cohortId: string }) {
  const coverage = await mentorship.computeMentorshipCoverageForCohort(cohortId);
  if (coverage.founderCount === 0) return null;
  return (
    <div style={{ fontSize: 12, color: "var(--text-faint)", marginTop: 2, marginLeft: 2 }}>
      Mentor coverage: {coverage.foundersWithActiveOrCompletedMentor}/{coverage.founderCount} founders matched ·{" "}
      {coverage.totalSessionsLogged} session{coverage.totalSessionsLogged === 1 ? "" : "s"} logged
      {coverage.overdueCheckins > 0 && (
        <span style={{ color: "var(--gap, #b3413a)" }}> · {coverage.overdueCheckins} check-in{coverage.overdueCheckins === 1 ? "" : "s"} overdue</span>
      )}
    </div>
  );
}

/** Cohort roster with real status changes and same-programme transfer
 * (D-016, docs/DECISION_LOG.md) — the `cohort_memberships.status` column
 * has supported graduated/withdrawn/deferred since D-004, but this is the
 * first UI action that actually writes anything other than 'active'. */
async function CohortRoster({ cohort, allCohorts }: { cohort: inst.Cohort; allCohorts: inst.Cohort[] }) {
  const members = await inst.listCohortMembersWithNames(cohort.id);
  const transferTargets = allCohorts.filter((c) => c.id !== cohort.id);
  if (members.length === 0) return null;
  return (
    <details style={{ marginTop: 2, marginLeft: 2 }}>
      <summary style={{ cursor: "pointer", fontSize: 12, color: "var(--accent)" }}>
        {members.length} founder{members.length === 1 ? "" : "s"}
      </summary>
      <ul className="mt-1 flex flex-col gap-1" style={{ fontSize: 12 }}>
        {members.map((m) => (
          <li key={m.id} className="flex items-center justify-between gap-2 flex-wrap" style={{ padding: "3px 0" }}>
            <span>
              {m.userName} <span style={{ color: "var(--text-faint)" }}>({m.userEmail})</span>{" "}
              <span className="badge badge-grey" style={{ fontSize: 10 }}>{m.status}</span>
            </span>
            <span className="flex gap-1 items-center flex-wrap">
              <form action={updateCohortMembershipStatusAction.bind(null, m.id)} className="flex gap-1 items-center">
                <select name="status" defaultValue={m.status} className="field-input" style={{ fontSize: 11, padding: "1px 4px" }}>
                  <option value="active">Active</option>
                  <option value="graduated">Graduated</option>
                  <option value="deferred">Deferred</option>
                  <option value="withdrawn">Withdrawn</option>
                </select>
                <button type="submit" className="btn btn-ghost btn-sm" style={{ fontSize: 11, padding: "1px 6px" }}>Update</button>
              </form>
              {transferTargets.length > 0 && (
                <form action={transferCohortMembershipAction.bind(null, m.id)} className="flex gap-1 items-center">
                  <select name="targetCohortId" defaultValue="" className="field-input" style={{ fontSize: 11, padding: "1px 4px" }}>
                    <option value="" disabled>Transfer to…</option>
                    {transferTargets.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                  <button type="submit" className="btn btn-ghost btn-sm" style={{ fontSize: 11, padding: "1px 6px" }} disabled={m.status !== "active"}>Transfer</button>
                </form>
              )}
            </span>
          </li>
        ))}
      </ul>
    </details>
  );
}

async function ProgrammeRow({ programme, userId }: { programme: inst.Programme; userId: string }) {
  const cohorts = await inst.listCohorts(programme.id);
  const applications = await inst.listApplicationsForProgramme(programme.id);
  const form = await inst.getApplicationForm(programme.id);
  const rubric = await inst.getRubricForProgramme(programme.id);
  const criteria = rubric?.criteria ?? [];
  const weeks = await inst.listProgrammeWeeks(programme.id);

  return (
    <div className="card pad">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <b>{programme.title}</b>{" "}
          <span style={{ color: "var(--text-faint)", fontSize: 13 }}>({programme.programmeType.replace(/_/g, " ")}, {programme.ageGroup})</span>
        </div>
        <form action={async (fd: FormData) => { "use server"; await updateProgrammeStatusAction(programme.id, String(fd.get("status"))); }} className="flex gap-2 items-center">
          <select name="status" defaultValue={programme.status} className="field-input" style={{ fontSize: 13, padding: "2px 6px" }}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="applications_open">Applications open</option>
            <option value="applications_closed">Applications closed</option>
            <option value="running">Running</option>
            <option value="completed">Completed</option>
            <option value="archived">Archived</option>
          </select>
          <button type="submit" className="btn btn-ghost btn-sm">Update</button>
        </form>
      </div>

      <div className="flex gap-4 flex-wrap mt-3" style={{ fontSize: 14 }}>
        <div>
          <div style={{ color: "var(--text-faint)" }}>Cohorts ({cohorts.length})</div>
          <ul style={{ marginTop: 4 }}>
            {await Promise.all(cohorts.map(async (c) => (
              <li key={c.id}>
                {c.name} — <span className="badge badge-grey" style={{ fontSize: 11 }}>{c.status}</span>
                <MentorCoverageLine cohortId={c.id} />
                <FacilitatorCoverageLine cohortId={c.id} />
                <CohortRoster cohort={c} allCohorts={cohorts} />
                <FacilitatedSessionLog cohort={c} userId={userId} weeks={weeks} />
              </li>
            )))}
          </ul>
          <form action={createCohortAction.bind(null, programme.id)} className="flex gap-2 mt-2">
            <input name="name" required className="field-input" placeholder="New cohort name" style={{ fontSize: 13, maxWidth: 180 }} />
            <button type="submit" className="btn btn-ghost btn-sm">Add cohort</button>
          </form>
          <FacilitatorReadiness programme={programme} userId={userId} />
        </div>

        <div style={{ flex: 1, minWidth: 260 }}>
          <div style={{ color: "var(--text-faint)" }}>Applications ({applications.length})</div>
          {applications.length === 0 && <p style={{ color: "var(--text-faint)", fontSize: 13 }}>None submitted yet.</p>}
          <div className="flex flex-col gap-2 mt-2">
            {applications.map((app) => (
              <ApplicationRow key={app.id} application={app} cohorts={cohorts} userId={userId} criteria={criteria} />
            ))}
          </div>
        </div>
      </div>

      <details className="mt-3">
        <summary style={{ cursor: "pointer", fontSize: 14, color: "var(--accent)" }}>
          Evaluation rubric ({criteria.length} criteri{criteria.length === 1 ? "on" : "a"})
        </summary>
        <p style={{ color: "var(--text-faint)", fontSize: 12, marginTop: 4 }}>
          Weighted per-criterion scoring shown to evaluators on this programme&apos;s applications. No default
          criteria are seeded — a real rubric is your institution&apos;s own judgement call, not something to invent
          for you.
        </p>
        {criteria.length > 0 && (
          <ul className="mt-2" style={{ fontSize: 13 }}>
            {criteria.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-2" style={{ padding: "3px 0" }}>
                <span>
                  {c.label} <span style={{ color: "var(--text-faint)" }}>(weight {c.weight}, {c.kind.replace(/_/g, " ")})</span>
                </span>
                <form action={removeEvaluationCriterionAction.bind(null, programme.id, c.id)}>
                  <button type="submit" className="btn btn-ghost btn-sm">Remove</button>
                </form>
              </li>
            ))}
          </ul>
        )}
        <form action={addEvaluationCriterionAction.bind(null, programme.id)} className="flex gap-2 mt-2 flex-wrap items-center">
          <input name="label" required className="field-input" placeholder="Criterion (e.g. Founder-market fit)" style={{ fontSize: 13, maxWidth: 220 }} />
          <input name="weight" type="number" min={1} max={10} defaultValue={1} className="field-input" style={{ fontSize: 13, width: 70 }} title="Weight" />
          <select name="kind" className="field-input" style={{ fontSize: 13, maxWidth: 200 }}>
            <option value="human_judgement">Human judgement</option>
            <option value="objective_eligibility_rule">Objective eligibility rule</option>
            <option value="derived_metric">Derived metric</option>
            <option value="ai_assisted_observation">AI-assisted observation</option>
          </select>
          <button type="submit" className="btn btn-ghost btn-sm">Add criterion</button>
        </form>
      </details>

      {programme.status === "applications_open" && form && (
        <details className="mt-3">
          <summary style={{ cursor: "pointer", fontSize: 14, color: "var(--accent)" }}>Apply to this programme (as yourself)</summary>
          <form action={submitApplicationAction.bind(null, form.id)} className="flex flex-col gap-2 mt-2" style={{ maxWidth: 480 }}>
            {form.questions.map((question) => (
              <label key={question.id} style={{ fontSize: 13 }}>
                {question.label}
                {question.fieldType === "declaration" ? (
                  <div><input type="checkbox" name={`q_${question.id}`} value="yes" required={question.required} /> I agree</div>
                ) : (
                  <textarea name={`q_${question.id}`} required={question.required} className="field-input" style={{ width: "100%" }} />
                )}
              </label>
            ))}
            <button type="submit" className="btn btn-primary btn-sm">Submit application</button>
          </form>
        </details>
      )}
    </div>
  );
}

async function ApplicationRow({ application, cohorts, userId, criteria }: { application: inst.Application; cohorts: inst.Cohort[]; userId: string; criteria: inst.EvaluationCriterion[] }) {
  const applicant = await repo.getUserById(application.applicantUserId);
  const evaluations = ["under_evaluation", "selected", "not_selected", "waitlisted"].includes(application.status)
    ? await inst.listEvaluationsForApplication(application.id)
    : [];
  return (
    <div className="card pad" style={{ fontSize: 13 }}>
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <span>{applicant?.name || "Unknown applicant"}</span>
        <span className="badge badge-grey" style={{ fontSize: 11 }}>{application.status.replace(/_/g, " ")}</span>
      </div>
      {application.status === "submitted" && (
        <form action={async (fd: FormData) => { "use server"; await assignEvaluatorAction(application.id, String(fd.get("evaluatorEmail"))); }} className="flex gap-2 mt-2">
          <input name="evaluatorEmail" required type="email" placeholder="Evaluator's email" className="field-input" style={{ fontSize: 12, maxWidth: 180 }} />
          <button type="submit" className="btn btn-ghost btn-sm">Assign evaluator</button>
        </form>
      )}
      {evaluations.length > 0 && (
        <div className="mt-2 flex flex-col gap-1">
          {evaluations.map((ev) => (
            <div key={ev.id} style={{ fontSize: 12, color: "var(--text-faint)" }}>
              {ev.reasoning && <span>&ldquo;{ev.reasoning}&rdquo; </span>}
              {ev.weightedTotal !== null && (
                <span className="badge badge-grey" style={{ fontSize: 11 }}>
                  Weighted score: {ev.weightedTotal.toFixed(1)}
                  {ev.scores.length < criteria.length && criteria.length > 0 ? ` (${ev.scores.length}/${criteria.length} criteria)` : ""}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
      {application.status === "under_evaluation" && (
        <>
          <form action={submitEvaluationAction.bind(null, application.id)} className="flex flex-col gap-2 mt-2" style={{ maxWidth: 480 }}>
            {criteria.length > 0 && (
              <div className="flex flex-col gap-1">
                {criteria.map((c) => (
                  <label key={c.id} className="flex items-center justify-between gap-2" style={{ fontSize: 12 }}>
                    <span>{c.label} <span style={{ color: "var(--text-faint)" }}>(weight {c.weight})</span></span>
                    <input name={`score_${c.id}`} type="number" min={0} max={10} step="0.5" className="field-input" style={{ fontSize: 12, width: 64 }} placeholder="0–10" />
                  </label>
                ))}
              </div>
            )}
            <textarea name="reasoning" placeholder="Evaluator reasoning (if you're the assigned evaluator)" className="field-input" style={{ fontSize: 12 }} />
            <button type="submit" className="btn btn-ghost btn-sm" style={{ alignSelf: "flex-start" }}>Submit evaluation</button>
          </form>
          <div className="flex gap-2 mt-2 flex-wrap items-center">
            <form action={async (fd: FormData) => { "use server"; await selectAndEnrolAction(application.id, String(fd.get("cohortId")), "Selected after evaluation."); }} className="flex gap-2">
              <select name="cohortId" required className="field-input" style={{ fontSize: 12 }}>
                <option value="">Select into cohort…</option>
                {cohorts.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <button type="submit" className="btn btn-primary btn-sm" disabled={cohorts.length === 0}>Select &amp; enrol</button>
            </form>
            <form action={async () => { "use server"; await recordSelectionDecisionAction(application.id, "not_selected", "Not selected this cycle."); }}>
              <button type="submit" className="btn btn-ghost btn-sm">Not selected</button>
            </form>
          </div>
        </>
      )}
      {(application.status === "selected" || application.status === "not_selected" || application.status === "waitlisted") && (
        <p style={{ color: "var(--text-faint)", marginTop: 4 }}>Decision recorded — immutable (see audit log).</p>
      )}
    </div>
  );
}
