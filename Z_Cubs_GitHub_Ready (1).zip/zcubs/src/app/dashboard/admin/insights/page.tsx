import { requireUserId } from "@/lib/session";
import { hasRole } from "@/lib/institutional";
import { listPendingInsightCandidates } from "@/lib/insights";
import { approveInsightCandidateAction, rejectInsightCandidateAction } from "@/lib/actions";
import { Card, Notice } from "@/components/ui";

/**
 * D-021 (docs/DECISION_LOG.md): the human-review step for the insight
 * library — a founder's opt-in only ever creates a PENDING row; nothing
 * here goes live until a platform_super_administrator reads the real
 * submitted text, writes an anonymized version themselves, and approves
 * it. There is no auto-anonymization to trust.
 *
 * Honest gap: nothing in this release grants platform_super_administrator
 * to anyone — the same manual-DB-action gap D-011 already names for
 * setting a user's plan. A real admin console for role management is a
 * real follow-up, not built here (see docs/ROADMAP.md).
 */
export default async function InsightsAdminPage() {
  const userId = await requireUserId();
  const isAdmin = await hasRole(userId, "platform_super_administrator", "platform", "platform");

  if (!isAdmin) {
    return (
      <div>
        <div className="eyebrow">Insight Library</div>
        <h2 className="font-display text-[26px] mt-1">Review queue</h2>
        <div className="mt-4">
          <Notice tone="warn">
            This page is only visible to a platform administrator. If you believe you should have access, a
            platform_super_administrator role needs to be granted to your account (see docs/ROADMAP.md).
          </Notice>
        </div>
      </div>
    );
  }

  const pending = await listPendingInsightCandidates(userId);

  return (
    <div>
      <div className="eyebrow">Insight Library · Admin</div>
      <h2 className="font-display text-[26px] mt-1">Review queue</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        Founders opted these in to help guide other founders&apos; AI drafts. Nothing here is live yet — read the real
        submission, write the anonymized version yourself (strip any name, business name, or identifying detail),
        and approve. Reject anything that shouldn&apos;t be reused, no reason required.
      </p>

      {pending.length === 0 && (
        <div className="mt-4">
          <Notice>Nothing waiting on review right now.</Notice>
        </div>
      )}

      <div className="flex flex-col gap-4 mt-5">
        {pending.map((c) => (
          <Card key={c.id}>
            <div className="flex justify-between items-start gap-2 flex-wrap">
              <span className="badge" style={{ fontSize: 11 }}>{c.category}</span>
              <span style={{ fontSize: 12, color: "var(--text-faint)" }}>Submitted {new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
            <p className="mt-3" style={{ fontSize: 13, color: "var(--text-faint)" }}>Original submission (never shown to anyone else):</p>
            <pre style={{ whiteSpace: "pre-wrap", fontSize: 14, background: "var(--surface-2)", padding: 10, borderRadius: 6, marginTop: 4 }}>
              {c.submittedText}
            </pre>

            <form action={approveInsightCandidateAction} className="mt-3">
              <input type="hidden" name="id" value={c.id} />
              <label className="field-label">Anonymized version to actually use (required — write this yourself)</label>
              <textarea name="anonymizedText" className="field-input" rows={3} placeholder="e.g. A campus food-delivery idea targeting hostel students who can't leave during exam week" />
              <button type="submit" className="btn btn-primary btn-sm mt-2">Approve with this text</button>
            </form>

            <form action={rejectInsightCandidateAction} className="mt-2">
              <input type="hidden" name="id" value={c.id} />
              <input type="hidden" name="note" value="Not suitable for reuse." />
              <button type="submit" className="btn btn-ghost btn-sm">Reject</button>
            </form>
          </Card>
        ))}
      </div>
    </div>
  );
}
