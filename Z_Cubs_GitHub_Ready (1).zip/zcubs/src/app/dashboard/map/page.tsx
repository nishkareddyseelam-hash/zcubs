import { requireUserId } from "@/lib/session";
import { getTerritories } from "@/lib/territories";
import TerritoryMap from "@/components/TerritoryMap";

export default async function MapPage() {
  const userId = await requireUserId();
  const territories = await getTerritories(userId);

  return (
    <div>
      <div className="eyebrow">Founder World</div>
      <h2 className="font-display text-[26px] mt-1">A working map, not a game board</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "64ch" }}>
        Territories mark real work you&apos;ve done in this workspace, not fabricated progress. Nothing is artificially locked.
      </p>
      <div className="mt-5"><TerritoryMap territories={territories} /></div>
    </div>
  );
}
