import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { addComparableCompany, removeComparable } from "@/lib/actions";
import { Card, Notice } from "@/components/ui";
import JourneyBar from "@/components/JourneyBar";
import ComparableForm from "@/components/ComparableForm";
import RecheckComparable from "@/components/RecheckComparable";

export default async function ComparablesPage() {
  const userId = await requireUserId();
  const items = await repo.listComparableCompanies(userId);
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const stale = await repo.staleComparables(userId);

  return (
    <div>
      <div className="eyebrow">Comparable Outcomes</div>
      <h2 className="font-display text-[26px] mt-1">Comparable-Company Tracker</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        There is no success score or auto-generated outcome anywhere on this page. Every row is a company you add yourself, with a source, and a
        status that must be explicitly rechecked over time. &quot;Unknown&quot; is always an honest answer here — a stale &quot;shut down&quot; label
        presented as current fact is exactly the failure mode this module is built to avoid.
      </p>
      <JourneyBar step="comparables" activeIdea={activeIdea} opportunityCount={opportunities.length} />

      {stale.length > 0 && (
        <div className="mt-4">
          <Notice tone="warn">
            {stale.length} comparable{stale.length === 1 ? " has" : "s have"} not been rechecked in 90+ days (or ever) — status may be out of date.
          </Notice>
        </div>
      )}

      {items.length === 0 ? (
        <div className="mt-5"><Notice>No comparable companies logged yet. Add one below, with a real source.</Notice></div>
      ) : (
        <div className="flex flex-col gap-4 mt-5">
          {items.map((c) => (
            <Card key={c.id}>
              <div className="flex justify-between gap-3 flex-wrap">
                <div>
                  <h4 className="font-display text-[18px]">{c.name}</h4>
                  {c.opportunityId && (
                    <p style={{ fontSize: 14, color: "var(--text-faint)" }}>
                      Linked to: {opportunities.find((o) => o.id === c.opportunityId)?.title || "an idea that was removed"}
                    </p>
                  )}
                </div>
                <form action={removeComparable.bind(null, c.id)}><button className="btn btn-ghost btn-sm" type="submit">Remove</button></form>
              </div>
              <p className="mt-2" style={{ color: "var(--text-dim)" }}>{c.statusNote || "— no status note yet"}</p>
              {c.sourceUrl && (
                <p style={{ fontSize: 15 }}>
                  Source: {c.sourcePublisher || "—"} · <a href={c.sourceUrl} target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>link</a>
                </p>
              )}
              {c.notes && <p style={{ fontSize: 15, color: "var(--text-faint)" }}>{c.notes}</p>}
              <div className="mt-3"><RecheckComparable item={JSON.parse(JSON.stringify(c))} /></div>
            </Card>
          ))}
        </div>
      )}

      <Card className="mt-6">
        <h4 className="font-display text-[18px]">Add a comparable company</h4>
        <form action={addComparableCompany}>
          <ComparableForm opportunityId={activeIdea?.id} />
        </form>
      </Card>
    </div>
  );
}
