import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { addEcosystemContact, removeEcosystemContact } from "@/lib/actions";
import { Card, Notice } from "@/components/ui";
import JourneyBar from "@/components/JourneyBar";
import EcosystemForm from "@/components/EcosystemForm";
import EcosystemStatusSelect from "@/components/EcosystemStatusSelect";

const KIND_LABEL: Record<string, string> = {
  investor: "Investor", incubator: "Incubator", accelerator: "Accelerator", grant: "Grant / scheme", supplier: "Supplier", lender: "Lender",
};

export default async function EcosystemPage() {
  const userId = await requireUserId();
  const items = await repo.listEcosystemContacts(userId);
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const deadlines = await repo.upcomingDeadlines(userId);

  return (
    <div>
      <div className="eyebrow">Investor / Ecosystem Navigator</div>
      <h2 className="font-display text-[26px] mt-1">Investor, Incubator &amp; Grant Tracker</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        This is a tracker you build, not a directory we ship pre-filled — no investor, incubator or scheme name is seeded here, because none of that
        can be kept verified and current inside this build. Add each one from your own research (ideally with a source link), and track your own
        application status against it.
      </p>
      <JourneyBar step="ecosystem" activeIdea={activeIdea} opportunityCount={opportunities.length} />

      {deadlines.length > 0 && (
        <div className="mt-4">
          <Notice tone="warn">
            {deadlines.length} deadline{deadlines.length === 1 ? "" : "s"} in the next 21 days you haven&apos;t applied to yet:{" "}
            {deadlines.map((d) => d.name).join(", ")}.
          </Notice>
        </div>
      )}

      {items.length === 0 ? (
        <div className="mt-5"><Notice>Nothing tracked yet. Add an investor, incubator, grant, supplier or lender below.</Notice></div>
      ) : (
        <div className="table-wrap mt-5">
          <table>
            <thead><tr><th>Type</th><th>Name</th><th>Focus</th><th>Stage</th><th>Deadline</th><th>Status</th><th>Source</th><th></th></tr></thead>
            <tbody>
              {items.map((c) => (
                <tr key={c.id}>
                  <td>{KIND_LABEL[c.kind]}</td>
                  <td style={{ maxWidth: "22ch" }}>{c.name}</td>
                  <td style={{ fontSize: 15, color: "var(--text-faint)" }}>{c.focus || "—"}</td>
                  <td style={{ fontSize: 15, color: "var(--text-faint)" }}>{c.stage || "—"}</td>
                  <td style={{ fontSize: 15, color: "var(--text-faint)" }}>{c.deadline || "—"}</td>
                  <td><EcosystemStatusSelect id={c.id} initial={c.applicationStatus} /></td>
                  <td>{c.sourceUrl ? <a href={c.sourceUrl} target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>link</a> : "—"}</td>
                  <td><form action={removeEcosystemContact.bind(null, c.id)}><button className="btn btn-ghost btn-sm" type="submit">Remove</button></form></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Card className="mt-6">
        <h4 className="font-display text-[18px]">Add to tracker</h4>
        <form action={addEcosystemContact}>
          <EcosystemForm opportunityId={activeIdea?.id} />
        </form>
      </Card>
    </div>
  );
}
