import { REAL_COMPETITORS } from "@/lib/realEvidence";
import { Card, Notice } from "@/components/ui";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import JourneyBar from "@/components/JourneyBar";

// A comparable company's status can go stale — the same failure mode the
// competitor landscape review flagged in a rival product (a company shown
// as "failed" years after it had, in fact, kept operating). Rather than
// trusting a static label forever, compute how long it's been since this
// fact was actually verified and say so plainly.
function daysSince(dateStr: string): number | null {
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return null;
  return Math.floor((Date.now() - d.getTime()) / 86_400_000);
}
const RECHECK_AFTER_DAYS = 90;

export default async function RivalsPage() {
  const userId = await requireUserId();
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);

  return (
    <div>
      <div className="eyebrow">Rival Radar · Territory 6</div>
      <h2 className="font-display text-[26px] mt-1">Comparable-Business Report</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Three real Indian rental / co-living companies, included as reference comparables independent of any specific venture — this list does not
        change when you switch ideas. Every fact below is sourced; profitability is never inferred from funding, and product-market fit is never
        inferred from press coverage. Status labels expire — a company&apos;s current status is only ever as fresh as its last verification date,
        shown below.
      </p>
      <div className="mt-3">
        <Notice>
          Looking for competitors to <b>your</b> specific idea? This fixed reference list can&apos;t cover every venture. Add companies
          you&apos;ve actually researched to the <a href="/dashboard/comparables" style={{ color: "var(--accent)" }}>Comparable-Company Tracker</a>{" "}
          instead — it&apos;s linked to your active idea and only shows what you&apos;ve sourced yourself.
        </Notice>
      </div>
      <JourneyBar step="rivals" activeIdea={activeIdea} opportunityCount={opportunities.length} />
      <div className="grid md:grid-cols-3 gap-4 mt-5">
        {REAL_COMPETITORS.map((c) => {
          const age = daysSince(c.accessDate);
          const stale = age !== null && age > RECHECK_AFTER_DAYS;
          return (
            <Card key={c.name}>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <h4 className="font-display text-[18px]">{c.name}</h4>
                <span className={`badge ${stale ? "badge-amber" : "badge-green"}`}>
                  <span className="dot" />{stale ? "Recheck recommended" : "Recently verified"}
                </span>
              </div>
              <div className="mt-2">
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Geography</span><span>{c.geo}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Founded</span><span>{c.founded}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Founders</span><span>{c.founders}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Model</span><span>{c.model}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Funding</span><span>{c.funding}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Reported traction</span><span>{c.traction}</span></div>
              </div>
              <p className="mt-2" style={{ fontSize: 16, color: "var(--text-faint)" }}>
                Source: <a href={c.url} target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>{c.source}</a> · last verified {c.accessDate}
                {age !== null ? ` (${age} day${age === 1 ? "" : "s"} ago)` : ""}
              </p>
              <p className="mt-1" style={{ fontSize: 16, color: "var(--text-faint)" }}>Confidence: {c.confidence}</p>
              <p className="mt-1" style={{ fontSize: 16, color: "var(--text-faint)" }}><b>Unknowns:</b> {c.unknowns}</p>
              {stale && (
                <p className="mt-1" style={{ fontSize: 15, color: "var(--warn, #b45309)" }}>
                  This fact is older than {RECHECK_AFTER_DAYS} days — re-verify against the primary source before relying on it, especially before
                  citing its current operating status.
                </p>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
