import { requireUserId } from "@/lib/session";
import { getUserPlan, PLAN_LABELS, PLAN_CODES } from "@/lib/plans";
import { getAiUsageSummary } from "@/lib/aiQuota";
import { RAZORPAY_ENABLED, priceInrFor } from "@/lib/payments";
import { Card, Notice } from "@/components/ui";
import RazorpayCheckoutButton from "@/components/RazorpayCheckoutButton";

const PLANS: Array<[typeof PLAN_CODES[number], string]> = [
  ["free_explorer", "Founder discovery · limited Academy · 1 Opportunity Quest · 1 Idea Arena comparison"],
  ["founder_builder", "Full venture workspace · Validation Quest Lab · Evidence Passport · mentor guidance"],
  ["india_launch_pack", "Market + competitor reports · financial workbook · DPR · pitch deck · exports"],
  ["mentor_reviewed", "Human review of evidence, financials and documents"],
  ["institution", "Cohorts · mentor allocation · outcome dashboards · admin controls"],
  ["enterprise_government", "White-label · API access · advanced security · deployment options"],
];

/** D-011 (docs/DECISION_LOG.md): a real plan record per user, not just a
 * display-only page. D-020 added a real Razorpay checkout button per
 * priced plan — it only ever appears once RAZORPAY_ENABLED is true and a
 * price is actually configured for that plan (see src/lib/payments.ts);
 * on a deployment with no payment processor connected, this still falls
 * back to the honest admin-set-only state rather than showing a button
 * that looks like checkout but doesn't charge anyone. This page always
 * tells you which plan you're actually on and what it's really unlocking
 * today (the AI draft allowance), not invented feature gates. */
export default async function PricingPage() {
  const userId = await requireUserId();
  const [plan, aiUsage] = await Promise.all([getUserPlan(userId), getAiUsageSummary(userId)]);

  return (
    <div>
      <div className="eyebrow">Plans</div>
      <h2 className="font-display text-[26px] mt-1">Built for individuals through to government programmes</h2>

      <div className="mt-4">
        {RAZORPAY_ENABLED ? (
          <Notice tone="default">
            You&apos;re on <b>{PLAN_LABELS[plan.plan]}</b>. Plans with a price below are real, working checkouts via
            Razorpay — your plan updates automatically once payment is confirmed (see docs/DECISION_LOG.md D-020).
            Plans with no price shown are sold separately, not self-serve.
          </Notice>
        ) : (
          <Notice tone="default">
            You&apos;re on <b>{PLAN_LABELS[plan.plan]}</b>. There is no payment processor connected on this
            deployment yet, so plan changes here are set by an admin, not a self-serve checkout — nothing on this
            page charges you anything.
          </Notice>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-4 mt-5">
        {PLANS.map(([code, desc]) => {
          const priceInr = RAZORPAY_ENABLED ? priceInrFor(code) : null;
          return (
            <Card key={code}>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <h4 className="font-display text-[18px]">{PLAN_LABELS[code]}</h4>
                {code === plan.plan && <span className="badge badge-teal" style={{ fontSize: 11, padding: "2px 7px" }}>Your plan</span>}
              </div>
              <p className="mt-2" style={{ color: "var(--text-dim)" }}>{desc}</p>
              {priceInr !== null && code !== plan.plan && (
                <div className="mt-3">
                  <RazorpayCheckoutButton plan={code} label={PLAN_LABELS[code]} priceInr={priceInr} />
                </div>
              )}
            </Card>
          );
        })}
      </div>

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Your AI draft usage today</h4>
        <p style={{ fontSize: 13.5, color: "var(--text-dim)", marginTop: 4 }}>
          A real, live count of AI-assisted drafts you&apos;ve used today (suggestions, idea drafts, mentor chat
          replies, Guide field drafts) against your plan&apos;s daily allowance — a cost guardrail, not a paywall:
          when it&apos;s reached, those features keep working from the same curated/non-AI fallback used whenever no
          AI key is configured, never an error.
        </p>
        <p className="mt-3" style={{ fontVariantNumeric: "tabular-nums" }}>
          <b>{aiUsage.usedToday}</b> / {aiUsage.limit} used today on {PLAN_LABELS[plan.plan]}
        </p>
      </Card>

      <p className="mt-4" style={{ fontSize: 16, color: "var(--text-faint)" }}>
        {RAZORPAY_ENABLED
          ? "Prices shown are set by whoever operates this deployment (RAZORPAY_PRICE_INR_* env vars) — never invented by the product. Payment never influences evidence scores, investor matching or supplier rankings."
          : "Prices intentionally omitted here rather than shown as invented figures. Payment never influences evidence scores, investor matching or supplier rankings."}
      </p>
    </div>
  );
}
