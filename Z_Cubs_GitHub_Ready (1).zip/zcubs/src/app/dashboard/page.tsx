import Link from "next/link";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import * as inst from "@/lib/institutional";
import { REAL_EVIDENCE } from "@/lib/realEvidence";
import { getTerritories } from "@/lib/territories";
import { TREND_CATEGORIES } from "@/lib/trends";
import { CURATED_IDEA_SEEDS } from "@/lib/suggestData";
import { Card, Notice } from "@/components/ui";
import ScoreRing from "@/components/ScoreRing";
import GamificationPanel from "@/components/GamificationPanel";
import TerritoryMap from "@/components/TerritoryMap";
import TemplateTiles from "@/components/TemplateTiles";

export default async function HomePage() {
  const userId = await requireUserId();
  const profile = await repo.getFounderProfile(userId);
  const opportunities = await repo.listOpportunities(userId);
  const experiments = await repo.listExperiments(userId);
  const evidence = await repo.listEvidence(userId);
  const { total } = await repo.computeReadiness(userId);
  const gamification = await repo.computeGamification(userId);
  const territories = await getTerritories(userId);
  const programmeContext = await inst.getFounderProgrammeContext(userId);

  const nextStep = !profile
    ? { label: "Complete Self Discovery", href: "/dashboard/fitmap" }
    : opportunities.length === 0
    ? { label: "Add an Opportunity Card", href: "/dashboard/opportunities" }
    : opportunities.length < 2
    ? { label: "Add a second idea to compare", href: "/dashboard/opportunities" }
    : experiments.length === 0
    ? { label: "Define your first experiment", href: "/dashboard/validation" }
    : { label: "Review your Evidence Passport", href: "/dashboard/passport" };

  return (
    <div>
      <div className="eyebrow">India&apos;s evidence-led Founder Operating System</div>
      <h1 className="font-display mt-2" style={{ fontSize: "clamp(28px,4vw,42px)", lineHeight: 1.08, maxWidth: "15ch" }}>
        From curiosity to credible venture.
      </h1>
      <p className="mt-3" style={{ color: "var(--text-dim)", fontSize: 20, maxWidth: "56ch" }}>
        Every claim, forecast and recommendation here is traceable to evidence or clearly labelled as an assumption.
        This workspace starts empty on purpose — nothing you see is invented on your behalf.
      </p>
      <div className="flex gap-3 mt-5">
        <Link href="/dashboard/map" className="btn btn-primary">Enter Founder World</Link>
        <Link href="/dashboard/guide" className="btn btn-ghost">🧭 Open Guide</Link>
        <Link href={nextStep.href} className="btn btn-ghost">{nextStep.label} →</Link>
      </div>

      <div className="grid md:grid-cols-[300px_1fr] gap-4 mt-6 items-start">
        <Card>
          <div className="eyebrow">Venture readiness</div>
          <div className="flex items-center gap-4 mt-2">
            <ScoreRing value={total} size={104} />
            <p style={{ color: "var(--text-dim)", fontSize: 16 }}>
              {opportunities.length} opportunity card(s) · {experiments.length} experiment(s) · {evidence.length} evidence item(s) on file.
            </p>
          </div>
        </Card>
        <GamificationPanel
          streak={gamification.streak}
          badges={gamification.badges}
          earnedCount={gamification.earnedCount}
          badgeTotal={gamification.badgeTotal}
        />
      </div>

      <Notice>
        This is a real, database-backed workspace. Two kinds of content appear: real, cited facts, and your own inputs. Nothing is fabricated or presented as live data.
      </Notice>

      {programmeContext && (
        <Notice tone="good">
          You&apos;re enrolled in <strong>{programmeContext.institution.name}</strong>&apos;s{" "}
          <strong>{programmeContext.programme.title}</strong> programme, cohort{" "}
          <strong>{programmeContext.cohort.name}</strong>. Opportunity Cards you add from here are scoped to this
          cohort for your institution&apos;s dashboards.
        </Notice>
      )}

      <TemplateTiles trendNames={TREND_CATEGORIES.map((c) => c.name)} categories={CURATED_IDEA_SEEDS.map((s) => ({ id: s.id, label: s.label }))} />

      <section className="mt-6" aria-label="Your Founder World progress">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <h3 className="font-display text-[19px]">Founder World, at a glance</h3>
          <Link href="/dashboard/map" className="btn btn-ghost btn-sm">Open full map →</Link>
        </div>
        <TerritoryMap territories={territories} />
      </section>

      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <Card>
          <div className="eyebrow">Evidence Passport</div>
          <h3 className="font-display text-[19px] mt-1">{evidence.length + REAL_EVIDENCE.length} items on file</h3>
          <p className="mt-2" style={{ color: "var(--text-dim)", fontSize: 18 }}>1 real official-source item pre-loaded as an example.</p>
          <Link href="/dashboard/passport" className="btn btn-ghost btn-sm mt-3">Open passport →</Link>
        </Card>
        <Card>
          <div className="eyebrow">Recommended next</div>
          <h3 className="font-display text-[19px] mt-1">{nextStep.label}</h3>
          <p className="mt-2" style={{ color: "var(--text-dim)", fontSize: 18 }}>The product always names a real next step, never a generic nudge.</p>
          <Link href={nextStep.href} className="btn btn-ghost btn-sm mt-3">Go →</Link>
        </Card>
      </div>
    </div>
  );
}
