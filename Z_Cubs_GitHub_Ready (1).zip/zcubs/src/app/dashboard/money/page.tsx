import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import MoneyClient from "@/components/MoneyClient";
import JourneyBar from "@/components/JourneyBar";

export default async function MoneyPage() {
  const userId = await requireUserId();
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const scenarios = {
    conservative: await repo.getScenario(userId, "conservative"),
    base: await repo.getScenario(userId, "base"),
    upside: await repo.getScenario(userId, "upside"),
    stress: await repo.getScenario(userId, "stress"),
  };

  return (
    <div>
      <div className="eyebrow">Money Lab · Territory 7</div>
      <h2 className="font-display text-[26px] mt-1">Driver-based financial model</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Every field starts at zero and is saved to your account. Nothing is pre-filled as if it were researched — set the assumptions yourself and the
        model recalculates live.
      </p>
      <JourneyBar step="money" activeIdea={activeIdea} opportunityCount={opportunities.length} />
      <div className="mt-5"><MoneyClient initial={JSON.parse(JSON.stringify(scenarios))} /></div>
    </div>
  );
}
