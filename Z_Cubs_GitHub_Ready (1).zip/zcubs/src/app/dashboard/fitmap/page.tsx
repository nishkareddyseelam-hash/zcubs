import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { saveFounderProfile } from "@/lib/actions";
import { Card, Notice, Kv } from "@/components/ui";
import SmartSelect from "@/components/SmartSelect";
import SmartChips from "@/components/SmartChips";
import ReadinessWidget from "@/components/ReadinessWidget";
import Link from "next/link";

export default async function FitMapPage() {
  const userId = await requireUserId();
  const profile = await repo.getFounderProfile(userId);
  const discovery = await repo.computeDiscoveryReadiness(userId);

  return (
    <div>
      <div className="eyebrow">Self Discovery · Territory 1</div>
      <h2 className="font-display text-[26px] mt-1">Founder Fit Map</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Answer honestly — the map is generated only from what you type below, saved to your account, nothing pre-filled.
      </p>

      <Card className="mt-5">
        <ReadinessWidget title="Discovery Readiness" total={discovery.total} dims={discovery.dims} />
      </Card>

      {profile ? (
        <>
          <Notice tone="good">Everything below is exactly what you entered — nothing added.</Notice>
          <div className="grid md:grid-cols-2 gap-4 mt-5">
            <Card>
              <h4 className="font-display text-[18px]">Strengths, as you stated them</h4>
              <p className="mt-2" style={{ color: "var(--text-dim)" }}>{profile.strengths || "— not answered"}</p>
            </Card>
            <Card>
              <h4 className="font-display text-[18px]">To develop</h4>
              <p className="mt-2" style={{ color: "var(--text-dim)" }}>{profile.develop || "— not answered"}</p>
            </Card>
            <Card>
              <h4 className="font-display text-[18px]">Constraints</h4>
              <div className="mt-2">
                <Kv label="Time" value={profile.time || "—"} />
                <Kv label="Capital" value={profile.capital || "—"} />
                <Kv label="Risk tolerance" value={profile.risk} />
              </div>
            </Card>
            <Card>
              <h4 className="font-display text-[18px]">Categories of interest</h4>
              <p className="mt-2" style={{ color: "var(--text-dim)" }}>{profile.categories || "— not answered"}</p>
            </Card>
          </div>
          <div className="flex gap-3 mt-5">
            <details>
              <summary className="btn btn-ghost" style={{ display: "inline-flex", cursor: "pointer" }}>Edit answers</summary>
              <div className="mt-4"><ProfileForm profile={profile} /></div>
            </details>
            <Link href="/dashboard/opportunities" className="btn btn-primary">Continue to Opportunity Forest →</Link>
          </div>
        </>
      ) : (
        <Card className="mt-5">
          <ProfileForm profile={null} />
        </Card>
      )}
    </div>
  );
}

function ProfileForm({ profile }: { profile: repo.FounderProfile | null }) {
  return (
    <form action={saveFounderProfile} className="grid md:grid-cols-2 gap-4">
      <div className="md:col-span-2">
        <SmartChips
          name="strengths"
          label="One or two strengths you'd bring"
          field="fitmap.strengths"
          defaultValue={profile?.strengths}
          placeholder="Write your own strength, then Add"
          helpText="Pick what fits, or add your own — nothing here is filled in for you."
        />
      </div>
      <SmartSelect
        name="develop"
        label="A skill you know needs work"
        field="fitmap.develop"
        defaultValue={profile?.develop}
        placeholder="Choose a skill…"
      />
      <SmartSelect
        name="time"
        label="Time available per week"
        field="fitmap.time"
        defaultValue={profile?.time}
        placeholder="Choose time available…"
      />
      <SmartSelect
        name="capital"
        label="Capital available"
        field="fitmap.capital"
        context={{ risk: profile?.risk || "" }}
        defaultValue={profile?.capital}
        placeholder="Choose capital range…"
      />
      <div>
        <label className="field-label">Risk tolerance</label>
        <select name="risk" className="field-input" defaultValue={profile?.risk || "Medium"}>
          <option>Low</option><option>Medium</option><option>High</option>
        </select>
      </div>
      <div className="md:col-span-2">
        <SmartChips
          name="categories"
          label="Venture categories that interest you"
          field="fitmap.categories"
          defaultValue={profile?.categories}
          placeholder="Write your own category, then Add"
          helpText="Suggestions here include real, sourced sectors from Trend Radar — or click + Add to my Founder Fit Map on any card there."
        />
      </div>
      <div className="md:col-span-2">
        <button type="submit" className="btn btn-primary">Save my Founder Fit Map</button>
      </div>
    </form>
  );
}
