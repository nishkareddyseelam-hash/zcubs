import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { Notice } from "@/components/ui";
import JourneyBar from "@/components/JourneyBar";
import DprClient from "@/components/DprClient";

export default async function DprPage() {
  const userId = await requireUserId();
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const inputs = await repo.getDprInputs(userId);
  const computed = await repo.computeDpr(userId);

  return (
    <div>
      <div className="eyebrow">India Ledger · DPR-lite</div>
      <h2 className="font-display text-[26px] mt-1">Project Report Draft</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        India-specific project-cost, means-of-finance and DSCR structure, in the pattern lenders expect (modelled on Finline). Every figure below is
        either something you typed in, or a deterministic reducing-balance EMI/DSCR formula applied to it.
      </p>
      <JourneyBar step="dpr" activeIdea={activeIdea} opportunityCount={opportunities.length} />
      <div className="mt-4">
        <Notice tone="warn">
          This is a working draft for your own planning and lender conversations — not a certified project report. Lenders typically require a
          chartered accountant or approved agency to prepare or sign off on a DPR/CMA submission.
        </Notice>
      </div>
      <div className="mt-5"><DprClient initial={JSON.parse(JSON.stringify(inputs))} computed={JSON.parse(JSON.stringify(computed))} /></div>
    </div>
  );
}
