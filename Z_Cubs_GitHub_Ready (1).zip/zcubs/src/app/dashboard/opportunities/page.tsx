import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import * as inst from "@/lib/institutional";
import { removeOpportunity, setActiveOpportunity, shareOpportunityAsInsight } from "@/lib/actions";
import { hasSubmittedInsightForRef } from "@/lib/insights";
import { Badge, Card, Notice } from "@/components/ui";
import OpportunityForm from "@/components/OpportunityForm";
import JourneyBar from "@/components/JourneyBar";

export default async function OpportunitiesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; pattern?: string; businessName?: string; notes?: string }>;
}) {
  const userId = await requireUserId();
  const opportunities = await repo.listOpportunities(userId);
  const profile = await repo.getFounderProfile(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const programmeContext = await inst.getFounderProgrammeContext(userId);
  // Look up the real cohort/programme names actually stamped on each card
  // (not just the founder's *current* cohort — a founder could in principle
  // have older cards from a prior cohort) so the label is always accurate.
  const cohortLabelById = new Map<string, string>();
  for (const o of opportunities) {
    if (o.cohortId && !cohortLabelById.has(o.cohortId)) {
      const cohort = await inst.getCohort(o.cohortId);
      const programme = cohort ? await inst.getProgramme(cohort.programmeId) : undefined;
      if (cohort && programme) cohortLabelById.set(o.cohortId, `${cohort.name} · ${programme.title}`);
    }
  }
  // A home-page "ready to click" template tile links here with ?category=
  // (a real sourced Trend Radar sector name) or ?pattern= (a generic venture
  // pattern id) — passed straight through to auto-generate that draft.
  // ?businessName=/?notes= come from that same tile's "name your business"
  // modal, when the founder chose "Add as an Opportunity Card" there.
  const params = await searchParams;
  const sharedById = new Map<string, boolean>();
  for (const o of opportunities) {
    sharedById.set(o.id, await hasSubmittedInsightForRef("opportunity", o.id));
  }

  return (
    <div>
      <div className="eyebrow">Opportunity Forest · Territory 2</div>
      <h2 className="font-display text-[26px] mt-1">Opportunity Cards</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Build a card from a problem you&apos;ve actually observed and evidence you actually have — or generate a starting draft to edit. Saved to your account.
      </p>

      {opportunities.length === 0 && <Notice>No opportunity cards yet. Use the form below to add one from your own observation, or generate a draft to edit.</Notice>}

      {opportunities.length > 0 && (
        <Notice tone="default">
          Each card has a &quot;Share to help train Z Cubs&apos; AI&quot; button — entirely optional. Sharing sends the
          card for human review; if approved, an anonymized version may be shown to the AI as a reference example
          when it helps other founders (see docs/legal/PRIVACY_POLICY.md). Your card is never used automatically
          and never sent anywhere unreviewed.
        </Notice>
      )}

      {programmeContext && (
        <Notice tone="good">
          Cards added here are scoped to your <strong>{programmeContext.programme.title}</strong> cohort (
          <strong>{programmeContext.cohort.name}</strong>) at <strong>{programmeContext.institution.name}</strong> —
          visible on that institution&apos;s cohort dashboard.
        </Notice>
      )}

      <div className="grid md:grid-cols-3 gap-4 mt-5">
        {opportunities.map((o) => (
          <Card key={o.id}>
            <div className="flex justify-between items-start gap-2">
              <h4 className="font-display text-[18px]" style={{ maxWidth: "22ch" }}>{o.title}</h4>
              <form action={removeOpportunity.bind(null, o.id)}>
                <button type="submit" className="btn btn-ghost btn-sm">Remove</button>
              </form>
            </div>
            {opportunities.length >= 2 && (
              activeIdea?.id === o.id ? (
                <span className="badge badge-teal mt-2" style={{ display: "inline-flex" }}><span className="dot" />Active idea — journey follows this one</span>
              ) : (
                <form action={setActiveOpportunity.bind(null, o.id)} className="mt-2">
                  <button type="submit" className="btn btn-ghost btn-sm">Make this my active idea</button>
                </form>
              )
            )}
            <p className="mt-2 text-[18px]" style={{ color: "var(--text-dim)" }}><b>Problem:</b> {o.problem || "—"}</p>
            <p className="mt-1 text-[18px]" style={{ color: "var(--text-dim)" }}><b>Customer:</b> {o.customer || "—"}</p>
            <div className="mt-2"><Badge evClass={o.evidenceClass} text={o.evidenceClass === "assumption" ? "Assumption — not yet evidenced" : undefined} /></div>
            <p className="mt-1" style={{ color: "var(--text-faint)" }}>{o.evidenceNote || "No evidence note added."}</p>
            {o.cohortId && cohortLabelById.has(o.cohortId) && (
              <p className="mt-1 text-[14px]" style={{ color: "var(--text-faint)" }}>
                Scoped to {cohortLabelById.get(o.cohortId)}
              </p>
            )}
            <div className="mt-2">
              <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Difficulty</span><span>{o.difficulty}</span></div>
              <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Capital intensity</span><span>{o.capital}</span></div>
              <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>First validation mission</span><span>{o.mission || "—"}</span></div>
            </div>
            <div className="mt-3">
              {sharedById.get(o.id) ? (
                <span style={{ fontSize: 12.5, color: "var(--text-faint)" }}>Shared — awaiting review before it helps guide anyone else.</span>
              ) : (
                <form action={shareOpportunityAsInsight.bind(null, o.id)}>
                  <button type="submit" className="btn btn-ghost btn-sm">Share to help train Z Cubs&apos; AI</button>
                </form>
              )}
            </div>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <h4 className="font-display text-[18px]">Add an opportunity card</h4>
        <OpportunityForm
          profile={profile ? { strengths: profile.strengths, develop: profile.develop, categories: profile.categories } : undefined}
          initialCategory={params.category}
          initialPattern={params.pattern}
          initialBusinessName={params.businessName}
          initialNotes={params.notes}
        />
      </Card>

      <JourneyBar step="opportunities" activeIdea={activeIdea} opportunityCount={opportunities.length} />
    </div>
  );
}
