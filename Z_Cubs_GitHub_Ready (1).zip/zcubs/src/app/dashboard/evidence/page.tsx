import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { addEvidence, removeEvidence } from "@/lib/actions";
import { Badge, Card, Notice } from "@/components/ui";
import { REAL_EVIDENCE, REJECTED_EVIDENCE_NOTE } from "@/lib/realEvidence";
import EvidenceForm from "@/components/EvidenceForm";
import JourneyBar from "@/components/JourneyBar";

export default async function EvidencePage() {
  const userId = await requireUserId();
  const items = await repo.listEvidence(userId);
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const conflicts = await repo.findEvidenceConflicts(userId);
  const supersededIds = new Set(items.map((i) => i.supersedesId).filter(Boolean));
  const ideaContext = activeIdea
    ? { title: activeIdea.title, customer: activeIdea.customer, problem: activeIdea.problem, mission: activeIdea.mission }
    : undefined;

  return (
    <div>
      <div className="eyebrow">Evidence Lab &amp; Market Observatory · Territories 4–5</div>
      <h2 className="font-display text-[26px] mt-1">Evidence Register</h2>
      <JourneyBar step="evidence" activeIdea={activeIdea} opportunityCount={opportunities.length} />
      <Notice>
        No TAM/SAM/SOM figure is shown here for a specific venture. <Badge evClass="notfound" /> — a defensible market size needs a specific venture,
        geography and customer definition, then real primary or licensed-dataset research. Building one from population × an assumed price is exactly
        what this product refuses to do.
      </Notice>
      <div className="mt-3"><Notice tone="warn">{REJECTED_EVIDENCE_NOTE}</Notice></div>

      {conflicts.length > 0 && (
        <Card className="mt-5">
          <h4 className="font-display text-[18px]">⚠ {conflicts.length} claim{conflicts.length === 1 ? "" : "s"} with conflicting evidence</h4>
          <p style={{ fontSize: 15, color: "var(--text-faint)" }}>
            Detected automatically: the same claim has entries that disagree on metric or evidence class. Resolve by adding a corrected item that
            supersedes the outdated one, not by ignoring it.
          </p>
          <div className="flex flex-col gap-3 mt-3">
            {conflicts.map((c) => (
              <div key={c.claim} className="notice notice-warn">
                <b>{c.items[0].claim}</b>
                <ul style={{ marginTop: 6, paddingLeft: 18 }}>
                  {c.items.map((it) => (
                    <li key={it.id} style={{ fontSize: 15 }}>
                      {it.metric || "(no metric)"} — <Badge evClass={it.evClass} /> {it.publisher ? `· ${it.publisher}` : ""}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Register (real source pre-loaded, add your own below)</h4>
        <p style={{ fontSize: 15, color: "var(--text-faint)" }}>
          Every item can carry the same provenance fields as the pre-loaded reference: publisher, geography, the period the data covers, its licence,
          and the date it was accessed — so a claim can be checked and re-verified, not just trusted.
        </p>
        <div className="table-wrap mt-3">
          <table>
            <thead><tr><th>Claim</th><th>Metric</th><th>Class</th><th>Publisher / source</th><th>Geography</th><th>Data period</th><th>Date &amp; access</th><th>Idea</th></tr></thead>
            <tbody>
              {REAL_EVIDENCE.map((e) => (
                <tr key={e.claim}>
                  <td style={{ maxWidth: "26ch" }}>{e.claim}</td><td>{e.metric}</td><td><Badge evClass={e.cls} /></td>
                  <td style={{ fontSize: 18 }}>{e.publisher} · <a href={e.url} target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>source</a></td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>India (national)</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>AY 2023-24</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>{e.pubDate} · accessed {e.accessDate}</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>—</td>
                </tr>
              ))}
              {items.map((e) => (
                <tr key={e.id} style={supersededIds.has(e.id) ? { opacity: 0.5 } : undefined}>
                  <td style={{ maxWidth: "26ch" }}>
                    {e.claim}
                    {supersededIds.has(e.id) && <div style={{ fontSize: 13, color: "var(--text-faint)" }}>Superseded by a correction below</div>}
                    {e.supersedesId && <div style={{ fontSize: 13, color: "var(--text-faint)" }}>Corrects an earlier entry</div>}
                  </td><td>{e.metric}</td><td><Badge evClass={e.evClass} /></td>
                  <td style={{ fontSize: 18 }}>{e.publisher || "—"}{e.url ? <> · <a href={e.url} target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>source</a></> : null}</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>{e.geography || "—"}</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>{e.dataPeriod || "—"}</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>{e.accessDate ? `accessed ${e.accessDate}` : "—"}</td>
                  <td style={{ fontSize: 16, color: "var(--text-faint)" }}>
                    {e.opportunityId ? opportunities.find((o) => o.id === e.opportunityId)?.title || "—" : "—"}
                  </td>
                  <td>
                    <form action={removeEvidence.bind(null, e.id)}><button className="btn btn-ghost btn-sm" type="submit">Remove</button></form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Add an evidence item</h4>
        <form action={addEvidence}>
          <EvidenceForm ideaContext={ideaContext} opportunityId={activeIdea?.id} existingItems={items.map((i) => ({ id: i.id, claim: i.claim }))} />
        </form>
      </Card>
    </div>
  );
}
