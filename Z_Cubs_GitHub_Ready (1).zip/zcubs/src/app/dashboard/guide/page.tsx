import Link from "next/link";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { GUIDE_CHAPTERS } from "@/lib/guideStructure";
import { Card } from "@/components/ui";
import GuideNameBusinessPrompt from "@/components/GuideNameBusinessPrompt";

/** Guide landing page — in the spirit of IdeaBuddy's own Guide welcome
 * screen: four chapters, each with its own step list, walking a founder
 * from concept through projections. Progress is computed from real rows
 * already saved (per-step content, plus real Opportunity/DPR/Money Lab
 * data for linked steps) — never a fabricated "% complete". */
export default async function GuidePage() {
  const userId = await requireUserId();
  const allSaved = await repo.getAllGuideSteps(userId);
  const meta = await repo.getGuideMeta(userId);

  const chapterProgress = GUIDE_CHAPTERS.map((chapter) => {
    const done = chapter.steps.filter((s) => allSaved[s.id] && repo.guideStepHasContent(allSaved[s.id])).length;
    return { chapter, done, total: chapter.steps.length };
  });

  return (
    <div>
      <div className="eyebrow">Guide{meta.businessName ? ` · ${meta.businessName}` : ""}</div>
      <h2 className="font-display text-[26px] mt-1">{meta.businessName ? `A step-by-step journey for ${meta.businessName}` : "Welcome to Guide"}</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        Guide walks you through every stage of planning your venture — concept, research, set-up and projections — one short step at a time.
        You can start wherever you like, but Concept is a good place to set the stage for everything else. Wherever Z Cubs already has real,
        sourced or founder-entered data for a topic (Trend Radar, Rival Radar, India Ledger, Money Lab), a step links straight to it instead of
        asking you to re-enter the same numbers.
        {meta.businessName ? ` Fields already filled in below are starting drafts built from "${meta.businessName}"${meta.notes ? " and your own notes" : ""} — review and edit before you consider a field done.` : ""}
      </p>

      {!meta.businessName && <GuideNameBusinessPrompt />}

      <div className="grid md:grid-cols-2 gap-4 mt-6">
        {chapterProgress.map(({ chapter, done, total }) => (
          <Card key={chapter.id}>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="font-display text-[19px]">{chapter.title}</h3>
              <span className="badge badge-grey" style={{ fontSize: 13 }}>{done}/{total} steps started</span>
            </div>
            <p className="mt-1" style={{ color: "var(--text-dim)", fontSize: 16 }}>{chapter.tagline}</p>
            <div className="flex flex-col gap-1 mt-3">
              {chapter.steps.map((s) => {
                const hasContent = allSaved[s.id] && repo.guideStepHasContent(allSaved[s.id]);
                return (
                  <Link key={s.id} href={`/dashboard/guide/${chapter.id}/${s.id}`} className="flex items-center justify-between" style={{ fontSize: 15, color: "var(--accent)", padding: "3px 0" }}>
                    <span>{s.title}</span>
                    <span style={{ color: hasContent ? "var(--good)" : "var(--text-faint)" }}>{hasContent ? "✓ Started" : "Start here →"}</span>
                  </Link>
                );
              })}
            </div>
            <Link href={`/dashboard/guide/${chapter.id}`} className="btn btn-ghost btn-sm mt-3">Open {chapter.title} chapter →</Link>
          </Card>
        ))}
      </div>
    </div>
  );
}
