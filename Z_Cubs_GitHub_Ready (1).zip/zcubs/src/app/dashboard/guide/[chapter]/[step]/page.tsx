import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { GUIDE_CHAPTERS, findStep, stepNeighbors } from "@/lib/guideStructure";
import GuideFieldEditor from "@/components/GuideFieldEditor";
import GuideItemList from "@/components/GuideItemList";
import GuideSwotGrid from "@/components/GuideSwotGrid";
import GuideNotes from "@/components/GuideNotes";
import GuideInfoPanel from "@/components/GuideInfoPanel";
import GuideStepAutoFill from "@/components/GuideStepAutoFill";

export default async function GuideStepPage({ params }: { params: Promise<{ chapter: string; step: string }> }) {
  const userId = await requireUserId();
  const { chapter: chapterId, step: stepId } = await params;
  const found = findStep(chapterId, stepId);
  if (!found) notFound();
  const { chapter, step } = found;

  const profile = await repo.getFounderProfile(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const row = await repo.getGuideStep(userId, step.id);
  const meta = await repo.getGuideMeta(userId);
  const { prev, next } = stepNeighbors(chapterId, stepId);

  const opportunityCtx = activeIdea ? { title: activeIdea.title, customer: activeIdea.customer, problem: activeIdea.problem } : undefined;
  const profileCtx = profile ? { strengths: profile.strengths, categories: profile.categories } : undefined;
  const stepIsEmpty = !await repo.guideStepHasContent(row);
  const hasGuideContext = !!(activeIdea || meta.businessName);

  return (
    <div>
      <div className="flex gap-2 flex-wrap mb-2">
        {GUIDE_CHAPTERS.map((c) => (
          <Link key={c.id} href={`/dashboard/guide/${c.id}`} className="btn btn-sm" style={c.id === chapter.id ? { background: "var(--accent-grad)", color: "#fff", boxShadow: "var(--shadow-pop)" } : { background: "var(--bg-raise)", color: "var(--text-dim)" }}>
            {c.title}
          </Link>
        ))}
      </div>
      <div className="flex gap-2 flex-wrap mb-4">
        {chapter.steps.map((s) => (
          <Link key={s.id} href={`/dashboard/guide/${chapter.id}/${s.id}`} className="btn btn-ghost btn-sm" style={s.id === step.id ? { textDecoration: "underline", fontWeight: 700, color: "var(--accent)" } : {}}>
            {s.title}
          </Link>
        ))}
      </div>

      <div className="eyebrow">{chapter.title} · Guide</div>
      <h2 className="font-display text-[26px] mt-1">{step.title}</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>{step.tagline}</p>

      <GuideInfoPanel title={`Welcome to the ${step.title} section`}>{step.welcome}</GuideInfoPanel>

      <GuideStepAutoFill chapterId={chapter.id} stepId={step.id} empty={stepIsEmpty} hasContext={hasGuideContext} />

      {step.linked && step.linked.length > 0 && (
        <div className="grid md:grid-cols-2 gap-3 mt-4">
          {step.linked.map((l) => (
            <Link key={l.href} href={l.href} className="card pad" style={{ display: "block", textDecoration: "none", color: "inherit" }}>
              <div style={{ fontSize: 14, color: "var(--accent)", fontWeight: 700 }}>Real data already in your account</div>
              <h4 className="font-display" style={{ fontSize: 16, marginTop: 4 }}>{l.label} →</h4>
              <p style={{ fontSize: 14, color: "var(--text-dim)", marginTop: 4 }}>{l.note}</p>
            </Link>
          ))}
        </div>
      )}

      {step.fields.length > 0 && (
        <div className="flex flex-col gap-4 mt-4">
          {step.fields.map((f) => (
            <GuideFieldEditor
              key={`${f.key}-${row.updatedAt}`}
              chapterId={chapter.id}
              stepId={step.id}
              field={f}
              initialValue={row.fields[f.key] || ""}
              opportunity={opportunityCtx}
              profile={profileCtx}
              siblingValues={row.fields}
            />
          ))}
        </div>
      )}

      {step.itemSchema && (
        <GuideItemList key={`items-${row.updatedAt}`} stepId={step.id} schema={step.itemSchema} initialItems={(row.items[step.itemSchema.listKey] as Record<string, string>[]) || []} />
      )}

      {step.swot && (
        <GuideSwotGrid key={`swot-${row.updatedAt}`} stepId={step.id} initialItems={row.items as Record<string, string[]>} />
      )}

      <GuideNotes stepId={step.id} initialNotes={row.notes} />

      <div className="flex items-center justify-between mt-6 flex-wrap gap-2">
        {prev ? (
          <Link href={`/dashboard/guide/${prev.chapterId}/${prev.id}`} className="btn btn-ghost btn-sm">← {prev.title}</Link>
        ) : <span />}
        {next ? (
          <Link href={`/dashboard/guide/${next.chapterId}/${next.id}`} className="btn btn-primary btn-sm">Next: {next.title} →</Link>
        ) : (
          <Link href="/dashboard/guide" className="btn btn-primary btn-sm">Back to Guide overview</Link>
        )}
      </div>
    </div>
  );
}
