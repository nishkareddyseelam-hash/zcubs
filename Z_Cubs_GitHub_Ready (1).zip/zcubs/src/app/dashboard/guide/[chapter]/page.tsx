import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { GUIDE_CHAPTERS } from "@/lib/guideStructure";
import { Card } from "@/components/ui";

export default async function GuideChapterPage({ params }: { params: Promise<{ chapter: string }> }) {
  const userId = await requireUserId();
  const { chapter: chapterId } = await params;
  const chapter = GUIDE_CHAPTERS.find((c) => c.id === chapterId);
  if (!chapter) notFound();

  const allSaved = await repo.getAllGuideSteps(userId);

  return (
    <div>
      <div className="flex gap-2 flex-wrap mb-2">
        {GUIDE_CHAPTERS.map((c) => (
          <Link key={c.id} href={`/dashboard/guide/${c.id}`} className="btn btn-sm" style={c.id === chapter.id ? { background: "var(--accent-grad)", color: "#fff", boxShadow: "var(--shadow-pop)" } : { background: "var(--bg-raise)", color: "var(--text-dim)" }}>
            {c.title}
          </Link>
        ))}
      </div>
      <div className="eyebrow">Guide · {chapter.title}</div>
      <h2 className="font-display text-[26px] mt-1">{chapter.title} chapter</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>{chapter.tagline} Here are all the steps in this chapter.</p>

      <div className="flex flex-col gap-3 mt-5">
        {chapter.steps.map((s, i) => {
          const hasContent = allSaved[s.id] && repo.guideStepHasContent(allSaved[s.id]);
          return (
            <Card key={s.id}>
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div>
                  <div className="eyebrow">Step {i + 1}</div>
                  <h4 className="font-display text-[18px] mt-1">{s.title}</h4>
                  <p className="mt-1" style={{ color: "var(--text-dim)", fontSize: 16, maxWidth: "60ch" }}>{s.tagline}</p>
                </div>
                <Link href={`/dashboard/guide/${chapter.id}/${s.id}`} className="btn btn-primary btn-sm" style={{ flexShrink: 0 }}>
                  {hasContent ? "Continue" : "Start here"}
                </Link>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
