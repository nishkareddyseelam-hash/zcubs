import { requireUserId } from "@/lib/session";
import * as mentorship from "@/lib/mentorship";
import * as repo from "@/lib/repo";
import * as consent from "@/lib/consent";
import {
  upsertMentorProfileAction, setMentorStatusAction, requestMentorshipAction,
  respondToRequestAction, markRequestCompletedAction, logMentorshipSessionAction, setNextCheckinAction,
} from "@/lib/actions";
// (imported for the server-action closures above; keep even though some are
// only referenced through inline "use server" wrapper functions)
import { Card, Notice } from "@/components/ui";

/** Mentor Discovery & Matching (D-008, docs/DECISION_LOG.md) — combines two
 * real reference patterns without copying either platform's branding:
 * Wadhwani Foundation's structured, logged mentor relationship (a session
 * log with summary + next steps, not an untracked chat) and MAARG
 * (Startup India)'s founder-driven ranked discovery + request/accept flow,
 * rather than a top-down assignment. Match scores are computed only from
 * real stored text (your Self Discovery categories + Opportunity Card
 * missions vs. each mentor's stated expertise) — never fabricated. */
export default async function MentorsPage() {
  const userId = await requireUserId();
  const [myMentorProfile, matches, myRequestsAsFounder, myRequestsAsMentor, user] = await Promise.all([
    mentorship.getMentorProfileByUser(userId),
    mentorship.matchMentorsForFounder(userId),
    mentorship.listRequestsForFounder(userId),
    mentorship.listRequestsForMentor(userId),
    repo.getUserById(userId),
  ]);
  const requestedMentorIds = new Set(myRequestsAsFounder.filter((r) => r.status === "requested" || r.status === "accepted").map((r) => r.mentorUserId));
  // D-012: a mentor is an adult verified only by their own account — real
  // adult-minor contact for an Explorer founder, so requesting one is
  // gated on a confirmed guardian, the same way a risky real-world
  // experiment is. Nothing else on this page is gated.
  const needsGuardian = user?.ageBand === "explorer" && !(await consent.hasConfirmedGuardianConsent(userId));

  return (
    <div>
      <div className="eyebrow">Mentor Discovery &amp; Matching</div>
      <h2 className="font-display text-[26px] mt-1">Find a mentor, or become one</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        Ranked by real overlap with your Self Discovery categories and Opportunity Card missions, plus each
        mentor&apos;s real available capacity — MAARG-style discovery, not a top-down assignment, with the ranking
        factors shown rather than hidden behind an &quot;AI/ML&quot; label. Once a mentor accepts, every conversation gets
        a logged session (date, summary, next steps) and a shared next check-in date, the way Wadhwani-style
        mentoring tracks a relationship over time with a real cadence, not a one-off chat.
      </p>

      {needsGuardian && (
        <div className="mt-3">
          <Notice tone="warn">
            Your account is registered as Explorer (13&ndash;17) with no confirmed guardian yet. A mentor is an
            adult verified only by their own account, so requesting one needs a confirmed guardian first.{" "}
            <a href="/dashboard/privacy">Add one on Privacy &amp; Consent</a>.
          </Notice>
        </div>
      )}

      {/* ---------- Become a mentor ---------- */}
      <Card className="mt-5">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h4 className="font-display text-[18px]">{myMentorProfile ? "Your mentor profile" : "Become a mentor"}</h4>
          {myMentorProfile && (
            <form action={async () => { "use server"; await setMentorStatusAction(myMentorProfile.status === "active" ? "paused" : "active"); }}>
              <button type="submit" className="btn btn-sm">{myMentorProfile.status === "active" ? "Pause my profile" : "Reactivate my profile"}</button>
            </form>
          )}
        </div>
        {myMentorProfile?.status === "paused" && <Notice tone="default">Your profile is paused — founders won&apos;t see you in matches until you reactivate it.</Notice>}
        <form action={upsertMentorProfileAction} className="flex flex-col gap-2 mt-3" style={{ maxWidth: 560 }}>
          <input name="headline" defaultValue={myMentorProfile?.headline} required className="field-input" placeholder="Headline (e.g. Ops &amp; unit economics for D2C)" />
          <textarea name="bio" defaultValue={myMentorProfile?.bio} className="field-input" placeholder="Short bio — what you can actually help with" rows={2} />
          <input name="expertiseTags" defaultValue={myMentorProfile?.expertiseTags} required className="field-input" placeholder="Expertise tags, comma-separated (e.g. pricing, GTM, fundraising)" />
          <input name="sectors" defaultValue={myMentorProfile?.sectors} className="field-input" placeholder="Sectors, comma-separated (e.g. EdTech, D2C, Sustainability)" />
          <div className="flex gap-2 flex-wrap">
            <select name="mentorshipMode" defaultValue={myMentorProfile?.mentorshipMode || "virtual"} className="field-input" style={{ maxWidth: 160 }}>
              <option value="virtual">Virtual</option>
              <option value="in_person">In person</option>
              <option value="hybrid">Hybrid</option>
            </select>
            <input name="languages" defaultValue={myMentorProfile?.languages || "English"} className="field-input" placeholder="Languages" style={{ maxWidth: 160 }} />
            <input name="capacityPerMonth" type="number" min={1} defaultValue={myMentorProfile?.capacityPerMonth || 4} className="field-input" placeholder="Founders/month" style={{ maxWidth: 140 }} />
          </div>

          <div className="mt-2" style={{ borderTop: "1px solid var(--line)", paddingTop: 10 }}>
            <label className="field-label">What qualifies you to mentor?</label>
            <textarea
              name="credentialsNote" defaultValue={myMentorProfile?.credentialsNote} required className="field-input"
              placeholder="e.g. 6 years as a product manager at a D2C startup; ran GTM for two product launches"
              rows={2}
            />
            <p style={{ fontSize: 13, color: "var(--text-faint)", marginTop: 4 }}>
              Self-declared — shown to founders exactly as &quot;self-declared, not verified by Z Cubs,&quot; not as a
              background-checked credential.
            </p>
          </div>

          <div className="flex gap-2 flex-wrap">
            <input name="referenceName" defaultValue={myMentorProfile?.referenceName} className="field-input" placeholder="Reference name (optional)" style={{ maxWidth: 200 }} />
            <input name="referenceEmail" type="email" defaultValue={myMentorProfile?.referenceEmail} className="field-input" placeholder="Reference email (optional)" style={{ maxWidth: 220 }} />
            <input name="referenceRelationship" defaultValue={myMentorProfile?.referenceRelationship} className="field-input" placeholder="How you know them" style={{ maxWidth: 180 }} />
          </div>
          <p style={{ fontSize: 13, color: "var(--text-faint)" }}>
            Optional — a contact a founder or institution could choose to reach out to themselves. Z Cubs never contacts them on your behalf.
          </p>

          <label className="flex items-start gap-2 mt-1" style={{ fontSize: 14 }}>
            <input type="checkbox" name="attestationConfirmed" required defaultChecked={myMentorProfile?.attestationConfirmed} style={{ marginTop: 3 }} />
            <span>I confirm the above is accurate to the best of my knowledge. I understand Z Cubs has not independently verified it.</span>
          </label>

          <button type="submit" className="btn btn-primary btn-sm" style={{ alignSelf: "flex-start" }}>
            {myMentorProfile ? "Save changes" : "Create my mentor profile"}
          </button>
        </form>
      </Card>

      {/* ---------- Incoming requests (as a mentor) ---------- */}
      {myRequestsAsMentor.length > 0 && (
        <Card className="mt-5">
          <h4 className="font-display text-[18px]">Founders who&apos;ve requested you</h4>
          <div className="flex flex-col gap-3 mt-3">
            {myRequestsAsMentor.map((r) => (
              <RequestRow key={r.id} request={r} otherName={r.founderName} viewerRole="mentor" />
            ))}
          </div>
        </Card>
      )}

      {/* ---------- My requests (as a founder) ---------- */}
      {myRequestsAsFounder.length > 0 && (
        <Card className="mt-5">
          <h4 className="font-display text-[18px]">Mentors you&apos;ve requested</h4>
          <div className="flex flex-col gap-3 mt-3">
            {myRequestsAsFounder.map((r) => (
              <RequestRow key={r.id} request={r} otherName={r.mentorName} viewerRole="founder" />
            ))}
          </div>
        </Card>
      )}

      {/* ---------- Ranked matches ---------- */}
      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Mentors for you</h4>
        {matches.length === 0 && <Notice tone="default">No mentor profiles exist yet — invite someone with a Z Cubs account to open one above.</Notice>}
        <div className="grid gap-3 mt-3">
          {matches.map((m) => {
            const alreadyRequested = requestedMentorIds.has(m.mentor.userId);
            return (
              <div key={m.mentor.id} className="card pad">
                <div className="flex items-start justify-between flex-wrap gap-2">
                  <div>
                    <b>{m.mentor.name}</b>{" "}
                    <span style={{ color: "var(--text-faint)", fontSize: 13 }}>— {m.mentor.headline || "No headline yet"}</span>
                    {m.mentor.institutionName && <span style={{ color: "var(--text-faint)", fontSize: 13 }}> · {m.mentor.institutionName}</span>}
                  </div>
                  <div className="flex gap-2 flex-wrap" style={{ justifyContent: "flex-end" }}>
                    {m.score > 0 ? (
                      <span className="badge badge-teal" style={{ fontSize: 12, padding: "3px 9px" }}>Overlap: {m.overlapTags.join(", ")}</span>
                    ) : (
                      <span style={{ color: "var(--text-faint)", fontSize: 12 }}>No tag overlap yet</span>
                    )}
                    {m.atCapacity ? (
                      <span className="badge badge-amber" style={{ fontSize: 12, padding: "3px 9px" }}>At capacity ({m.mentor.activeMenteeCount}/{m.mentor.capacityPerMonth})</span>
                    ) : (
                      <span style={{ color: "var(--text-faint)", fontSize: 12 }}>{m.mentor.activeMenteeCount}/{m.mentor.capacityPerMonth} active</span>
                    )}
                  </div>
                </div>
                {m.mentor.bio && <p style={{ fontSize: 13.5, color: "var(--text-dim)", marginTop: 6 }}>{m.mentor.bio}</p>}
                <p style={{ fontSize: 12.5, color: "var(--text-faint)", marginTop: 4 }}>
                  {m.mentor.expertiseTags} · {m.mentor.mentorshipMode.replace("_", " ")} · {m.mentor.languages} · up to {m.mentor.capacityPerMonth}/month
                </p>
                {m.mentor.credentialsNote && (
                  <div className="mt-2" style={{ fontSize: 13, borderLeft: "2px solid var(--line)", paddingLeft: 8 }}>
                    <span className="badge" style={{ fontSize: 10.5, padding: "1px 6px", marginRight: 6 }}>Self-declared, not verified</span>
                    {m.mentor.credentialsNote}
                    {m.mentor.referenceName && (
                      <div style={{ color: "var(--text-faint)", marginTop: 2 }}>
                        Reference (self-provided, not contacted by Z Cubs): {m.mentor.referenceName}
                        {m.mentor.referenceRelationship ? ` (${m.mentor.referenceRelationship})` : ""}
                        {m.mentor.referenceEmail ? ` — ${m.mentor.referenceEmail}` : ""}
                      </div>
                    )}
                  </div>
                )}
                {alreadyRequested ? (
                  <p style={{ fontSize: 13, color: "var(--text-faint)", marginTop: 8 }}>You already have an open request with this mentor.</p>
                ) : m.atCapacity ? (
                  <p style={{ fontSize: 13, color: "var(--text-faint)", marginTop: 8 }}>
                    This mentor is at their stated capacity right now — try again once they complete an existing mentorship, or a mentor below with room.
                  </p>
                ) : needsGuardian ? (
                  <p style={{ fontSize: 13, color: "var(--text-faint)", marginTop: 8 }}>
                    Add a confirmed guardian on Privacy &amp; Consent before requesting a mentor.
                  </p>
                ) : (
                  <form
                    action={async (fd: FormData) => { "use server"; await requestMentorshipAction(m.mentor.userId, fd); }}
                    className="flex flex-col gap-2 mt-2" style={{ maxWidth: 480 }}
                  >
                    <input name="focusArea" required className="field-input" placeholder="What do you want help with?" />
                    <textarea name="message" className="field-input" placeholder="A short message (optional)" rows={2} />
                    <button type="submit" className="btn btn-sm" style={{ alignSelf: "flex-start" }}>Request mentorship</button>
                  </form>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

async function RequestRow({
  request, otherName, viewerRole,
}: {
  request: { id: string; focusArea: string; message: string; status: string; declineNote: string; requestedAt: string; nextCheckinAt: string | null };
  otherName: string;
  viewerRole: "founder" | "mentor";
}) {
  const today = new Date().toISOString().slice(0, 10);
  const checkinOverdue = request.status === "accepted" && !!request.nextCheckinAt && request.nextCheckinAt < today;
  const sessions = request.status === "accepted" || request.status === "completed" ? await mentorship.listSessionsForRequest(request.id) : [];
  return (
    <div className="card pad">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <b>{otherName}</b> <span style={{ color: "var(--text-faint)", fontSize: 13 }}>— {request.focusArea}</span>
        </div>
        <div className="flex items-center gap-2">
          {checkinOverdue && <span className="badge badge-amber" style={{ fontSize: 11, padding: "2px 7px" }}>Check-in overdue</span>}
          <StatusPill status={request.status} />
        </div>
      </div>
      {request.message && <p style={{ fontSize: 13, color: "var(--text-dim)", marginTop: 4 }}>&ldquo;{request.message}&rdquo;</p>}
      {request.status === "declined" && request.declineNote && (
        <p style={{ fontSize: 13, color: "var(--text-faint)", marginTop: 4 }}>Declined: {request.declineNote}</p>
      )}

      {viewerRole === "mentor" && request.status === "requested" && (
        <div className="flex gap-2 mt-3 flex-wrap">
          <form action={async () => { "use server"; await respondToRequestAction(request.id, true); }}>
            <button type="submit" className="btn btn-primary btn-sm">Accept</button>
          </form>
          <form action={async (fd: FormData) => { "use server"; await respondToRequestAction(request.id, false, String(fd.get("declineNote") || "")); }} className="flex gap-2">
            <input name="declineNote" placeholder="Reason (optional)" className="field-input" style={{ maxWidth: 220 }} />
            <button type="submit" className="btn btn-sm">Decline</button>
          </form>
        </div>
      )}

      {request.status === "accepted" && (
        <div className="mt-3 flex items-center gap-2 flex-wrap" style={{ fontSize: 13 }}>
          <span style={{ color: "var(--text-faint)" }}>Next check-in:</span>
          {request.nextCheckinAt ? (
            <b style={{ color: checkinOverdue ? "var(--gap)" : "inherit" }}>{request.nextCheckinAt}{checkinOverdue ? " (overdue)" : ""}</b>
          ) : (
            <span style={{ color: "var(--text-faint)" }}>Not scheduled</span>
          )}
          <form action={async (fd: FormData) => { "use server"; await setNextCheckinAction(request.id, fd); }} className="flex gap-2 items-center">
            <input type="date" name="nextCheckinAt" defaultValue={request.nextCheckinAt || ""} className="field-input" style={{ maxWidth: 160 }} />
            <button type="submit" className="btn btn-sm">Set</button>
          </form>
        </div>
      )}

      {(request.status === "accepted" || request.status === "completed") && (
        <div className="mt-3">
          <div style={{ fontSize: 12.5, color: "var(--text-faint)", textTransform: "uppercase", letterSpacing: "0.04em" }}>Session log</div>
          {sessions.length === 0 && <p style={{ fontSize: 13, color: "var(--text-faint)" }}>No sessions logged yet.</p>}
          <div className="flex flex-col gap-2 mt-1">
            {sessions.map((s) => (
              <div key={s.id} style={{ fontSize: 13, borderLeft: "2px solid var(--line)", paddingLeft: 8 }}>
                <b>{s.sessionDate}</b> — {s.summary} {s.nextSteps && <span style={{ color: "var(--text-faint)" }}>(Next: {s.nextSteps})</span>}
                <span style={{ color: "var(--text-faint)" }}> · logged by {s.loggedByName}</span>
              </div>
            ))}
          </div>
          {request.status === "accepted" && (
            <form
              action={async (fd: FormData) => { "use server"; await logMentorshipSessionAction(request.id, fd); }}
              className="flex gap-2 mt-2 flex-wrap items-end"
            >
              <label style={{ fontSize: 12.5 }}>Date<input type="date" name="sessionDate" required className="field-input" style={{ display: "block" }} /></label>
              <input name="summary" required className="field-input" placeholder="What did you cover?" style={{ maxWidth: 260 }} />
              <input name="nextSteps" className="field-input" placeholder="Next steps" style={{ maxWidth: 200 }} />
              <button type="submit" className="btn btn-sm">Log session</button>
            </form>
          )}
          {request.status === "accepted" && (
            <form action={async () => { "use server"; await markRequestCompletedAction(request.id); }} className="mt-2">
              <button type="submit" className="btn btn-sm">Mark mentorship completed</button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const tone: Record<string, string> = {
    requested: "var(--text-faint)", accepted: "var(--good)", declined: "var(--gap)",
    completed: "var(--text-dim)", cancelled: "var(--text-faint)",
  };
  return <span style={{ fontSize: 12, color: tone[status] || "var(--text-faint)", textTransform: "uppercase", letterSpacing: "0.04em" }}>{status}</span>;
}
