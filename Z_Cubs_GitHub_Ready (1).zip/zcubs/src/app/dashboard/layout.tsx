import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import Shell from "@/components/Shell";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");
  const name = session.user.name || "Founder";
  const ageBand = (session.user as { ageBand?: string }).ageBand || "founder";
  return (
    <Shell userName={name} ageBand={ageBand}>
      {children}
    </Shell>
  );
}
