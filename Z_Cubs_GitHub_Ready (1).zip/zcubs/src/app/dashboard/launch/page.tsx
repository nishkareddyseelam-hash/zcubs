import { Card, Notice } from "@/components/ui";

const DOCS = [
  ["Venture Blueprint", "Full narrative + evidence appendix"],
  ["Detailed Project Report (DPR)", "Lender-oriented format"],
  ["Pitch Deck", "Investor-ready draft"],
  ["One-page Teaser", "Single-page summary"],
  ["Financial Workbook", "XLSX, all scenarios from Money Lab"],
  ["Risk & Assumptions Register", "Exported from your Evidence Passport"],
];

export default function LaunchPage() {
  return (
    <div>
      <div className="eyebrow">Pitch Studio &amp; India Launch Hub</div>
      <h2 className="font-display text-[26px] mt-1">India Launch Pack</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Document generation is not wired up in this release — a full build would render these from your Evidence Passport, never inventing traction,
        partnerships or approvals.
      </p>
      <div className="grid md:grid-cols-3 gap-4 mt-5">
        {DOCS.map(([title, desc]) => (
          <Card key={title}>
            <h4 className="font-display text-[16px]">{title}</h4>
            <p className="mt-1" style={{ color: "var(--text-dim)" }}>{desc}</p>
            <div className="mt-2"><span className="badge badge-grey"><span className="dot" />Planned — needs live generation service</span></div>
          </Card>
        ))}
      </div>
      <div className="mt-5"><Notice>Marked honestly as planned, not wired to a dead button.</Notice></div>
    </div>
  );
}
