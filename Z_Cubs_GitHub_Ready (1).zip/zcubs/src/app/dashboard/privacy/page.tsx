import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import * as consent from "@/lib/consent";
import {
  addGuardianAction, revokeGuardianAction, recordConsentAction, requestDataDeletionAction,
} from "@/lib/actions";
import { Card, Notice } from "@/components/ui";

/** Privacy & Consent (D-010, docs/DECISION_LOG.md) — a real DPDP Act
 * 2023-shaped consent trail, guardian-relationship record for explorer
 * (13-17) accounts, and data-subject-rights requests (access/export,
 * erasure). Everything here is a real, queryable record, not a static
 * "we take privacy seriously" page: consent decisions are appended to an
 * actual table, a guardian link is confirmed by an actual token, and the
 * "Download my data" button runs a real live export, not a mockup.
 *
 * Honesty boundary stated once, here and in consent.ts: nothing on this
 * page performs identity verification of a guardian — "confirmed" means
 * the confirm link was opened, the same bar most consumer double
 * opt-in flows use without a paid ID-check vendor. And this page is a data
 * layer, not a legal opinion — the Terms/Privacy text itself still needs a
 * lawyer's review before this is relied on with real minors. */
export default async function PrivacyPage() {
  const userId = await requireUserId();
  const user = await repo.getUserById(userId);
  const isExplorer = user?.ageBand === "explorer";

  const [guardians, consentStatus, dataRequests] = await Promise.all([
    isExplorer ? consent.listGuardianRelationships(userId) : Promise.resolve([]),
    consent.getConsentStatus(userId),
    consent.listDataRequests(userId),
  ]);

  const processingGranted = consentStatus["data_processing"]?.granted ?? false;

  return (
    <div>
      <div className="eyebrow">Privacy &amp; Consent</div>
      <h2 className="font-display text-[26px] mt-1">Your data, your choices</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        A real consent record, not a cookie-banner formality: every decision below is written to an append-only
        log, and the data export runs a live query over your own rows — the same data, nothing cached or summarized.
      </p>

      <div className="mt-4">
        <Notice tone="default">
          This page is a real data layer, not legal advice. It has not been reviewed by a lawyer against the DPDP
          Act 2023 — treat it as the honest starting model it is, not a compliance guarantee.
        </Notice>
      </div>

      {/* ---------- Consent ---------- */}
      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Data processing consent</h4>
        <p style={{ fontSize: 13.5, color: "var(--text-dim)", marginTop: 4 }}>
          Whether you consent to Z Cubs processing the data you enter (Self Discovery, Opportunity Cards, evidence,
          and so on) to run the product for you. Current status:{" "}
          <b style={{ color: processingGranted ? "var(--good)" : "var(--gap)" }}>{processingGranted ? "Granted" : "Not granted"}</b>
        </p>
        <form action={async () => { "use server"; await recordConsentAction("data_processing", !processingGranted); }} className="mt-3">
          <button type="submit" className="btn btn-sm">{processingGranted ? "Withdraw consent" : "Grant consent"}</button>
        </form>
      </Card>

      {/* ---------- Guardian relationships (explorer accounts only) ---------- */}
      {isExplorer && (
        <Card className="mt-5">
          <h4 className="font-display text-[18px]">Guardian</h4>
          <p style={{ fontSize: 13.5, color: "var(--text-dim)", marginTop: 4 }}>
            Your account is registered as Explorer (13&ndash;17). Add a parent or guardian&apos;s email below; they
            confirm by opening the link shown after you submit &mdash; no email-sending service is wired up yet
            (that&apos;s a separate, real follow-up), so pass the link along yourself for now.
          </p>
          <div className="flex flex-col gap-3 mt-3">
            {guardians.map((g) => (
              <div key={g.id} className="card pad">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <b>{g.guardianName}</b> <span style={{ color: "var(--text-faint)", fontSize: 13 }}>— {g.guardianEmail} · {g.relationship}</span>
                  </div>
                  <span
                    className={`badge ${g.status === "confirmed" ? "badge-teal" : g.status === "revoked" ? "badge-amber" : ""}`}
                    style={{ fontSize: 11, padding: "2px 7px", textTransform: "uppercase" }}
                  >
                    {g.status}
                  </span>
                </div>
                {g.status === "pending" && (
                  <p style={{ fontSize: 12.5, color: "var(--text-faint)", marginTop: 6, wordBreak: "break-all" }}>
                    Send this link to {g.guardianName}: <code>/guardian-confirm?rel={g.id}&amp;token={g.confirmToken}</code>
                  </p>
                )}
                {g.status !== "revoked" && (
                  <form action={async () => { "use server"; await revokeGuardianAction(g.id); }} className="mt-2">
                    <button type="submit" className="btn btn-sm">Revoke</button>
                  </form>
                )}
              </div>
            ))}
          </div>
          <AddGuardianForm />
        </Card>
      )}

      {/* ---------- Data rights ---------- */}
      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Your data</h4>
        <p style={{ fontSize: 13.5, color: "var(--text-dim)", marginTop: 4 }}>
          Download everything Z Cubs holds about you, or request deletion. Deletion is reviewed, not instant &mdash;
          the same &quot;prepared, human-reviewed&quot; pattern used for institutional exports &mdash; so a real
          person confirms before it runs.
        </p>
        <div className="flex gap-3 mt-3 flex-wrap items-center">
          <a href="/api/privacy/export" className="btn btn-sm">Download my data (JSON)</a>
          <form action={requestDataDeletionAction} className="flex gap-2 items-center">
            <input name="note" className="field-input" placeholder="Reason (optional)" style={{ maxWidth: 220 }} />
            <button type="submit" className="btn btn-sm">Request deletion</button>
          </form>
        </div>
        {dataRequests.length > 0 && (
          <div className="flex flex-col gap-2 mt-4">
            {dataRequests.map((r) => (
              <div key={r.id} style={{ fontSize: 13, color: "var(--text-faint)" }}>
                {r.requestType === "export" ? "Data export" : "Deletion request"} &mdash; {r.status} &mdash; {r.createdAt.slice(0, 10)}
                {r.note && ` — "${r.note}"`}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

function AddGuardianForm() {
  return (
    <form
      action={async (fd: FormData) => { "use server"; await addGuardianAction(fd); }}
      className="flex flex-col gap-2 mt-3"
      style={{ maxWidth: 420 }}
    >
      <input name="guardianName" required className="field-input" placeholder="Guardian's name" />
      <input name="guardianEmail" required type="email" className="field-input" placeholder="Guardian's email" />
      <input name="guardianPhone" className="field-input" placeholder="Guardian's phone (optional)" />
      <select name="relationshipType" className="field-input" defaultValue="parent/guardian">
        <option value="parent/guardian">Parent / guardian</option>
        <option value="school-designated adult">School-designated adult</option>
      </select>
      <button type="submit" className="btn btn-sm" style={{ alignSelf: "flex-start" }}>Add guardian</button>
    </form>
  );
}
