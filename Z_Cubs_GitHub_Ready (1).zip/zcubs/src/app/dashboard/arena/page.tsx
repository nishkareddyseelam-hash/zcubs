import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import ArenaClient from "@/components/ArenaClient";
import JourneyBar from "@/components/JourneyBar";
import Link from "next/link";

export default async function ArenaPage() {
  const userId = await requireUserId();
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);

  return (
    <div>
      <div className="eyebrow">Idea Arena · Territory 3</div>
      <h2 className="font-display text-[26px] mt-1">
        {opportunities.length >= 2 ? "Weighted Idea Comparison" : opportunities.length === 1 ? "Single-Idea Deep Dive" : "Idea Arena"}
      </h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Set both the weights (what matters to you) and each idea&apos;s dimension scores (your own honest 0–10 judgement) — every input is saved to your account.
      </p>
      <JourneyBar step="arena" activeIdea={activeIdea} opportunityCount={opportunities.length} />
      {opportunities.length === 0 ? (
        <div className="mt-5">
          <p style={{ color: "var(--text-faint)" }}>Add an Opportunity Card first — with one idea you get a full dimension-by-dimension deep dive; with two or more you get a side-by-side comparison.</p>
          <Link href="/dashboard/opportunities" className="btn btn-primary mt-3">Go to Opportunity Forest →</Link>
        </div>
      ) : (
        <div className="mt-5"><ArenaClient initial={JSON.parse(JSON.stringify(opportunities))} /></div>
      )}
    </div>
  );
}
