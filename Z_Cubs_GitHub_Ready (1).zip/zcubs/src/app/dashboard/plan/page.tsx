import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { Card, Notice } from "@/components/ui";
import JourneyBar from "@/components/JourneyBar";
import PlanClient from "@/components/PlanClient";
import ActualsClient from "@/components/ActualsClient";
import Link from "next/link";

export default async function PlanPage() {
  const userId = await requireUserId();
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const saved = await repo.getBusinessPlan(userId);
  const draft = await repo.assemblePlanDraft(userId);
  const checks = await repo.planConsistencyChecks(userId);
  const actuals = await repo.planVsActual(userId);

  const initial = JSON.parse(JSON.stringify(saved ?? { ...draft, userId, updatedAt: "" }));

  return (
    <div>
      <div className="eyebrow">Business Plan &amp; Operate/Monitor</div>
      <h2 className="font-display text-[26px] mt-1">Business Plan</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "70ch" }}>
        Assembled from real rows already in your account, editable in place, checked for internal consistency before you&apos;d call it &quot;ready&quot;
        — the pattern behind LivePlan and Upmetrics, without presenting anything as researched that you didn&apos;t actually enter or verify.
      </p>
      <JourneyBar step="plan" activeIdea={activeIdea} opportunityCount={opportunities.length} />

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Consistency checks</h4>
        <p style={{ fontSize: 15, color: "var(--text-faint)" }}>Real cross-references between rows that already exist in your account — not a generic &quot;looks investor-ready&quot; claim.</p>
        <div className="flex flex-col gap-2 mt-3">
          {checks.map((c, i) => (
            <div key={i} className="flex items-center gap-2" style={{ fontSize: 16 }}>
              <span style={{ color: c.ok ? "var(--good)" : "var(--bad)" }}>{c.ok ? "✓" : "✕"}</span>
              <span style={{ color: c.ok ? "var(--text-dim)" : "var(--text)" }}>{c.label}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mt-5">
        <PlanClient initial={initial} />
      </Card>

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Financial scenarios</h4>
        <p style={{ fontSize: 15, color: "var(--text-dim)" }}>
          Conservative, base, upside and stress cases live in Money Lab, each an independent set of the same seven driver assumptions.
        </p>
        <Link href="/dashboard/money" className="btn btn-ghost btn-sm mt-2">Open Money Lab →</Link>
      </Card>

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Operate / Monitor — plan vs. actual</h4>
        {actuals.length === 0 && <div className="mt-2"><Notice>No months logged yet — once you do, each is compared against your Money Lab base-case forecast for that month.</Notice></div>}
        <div className="mt-3"><ActualsClient rows={actuals} opportunityId={activeIdea?.id} /></div>
      </Card>
    </div>
  );
}
