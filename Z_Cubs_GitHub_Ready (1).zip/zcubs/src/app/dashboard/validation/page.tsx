import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import * as consent from "@/lib/consent";
import { removeExperiment } from "@/lib/actions";
import { Card, Notice } from "@/components/ui";
import ExperimentResultInput from "@/components/ExperimentResultInput";
import ValidationForm from "@/components/ValidationForm";
import JourneyBar from "@/components/JourneyBar";
import ReadinessWidget from "@/components/ReadinessWidget";

export default async function ValidationPage() {
  const userId = await requireUserId();
  const [experiments, opportunities, activeIdea, validationReadiness, user] = await Promise.all([
    repo.listExperiments(userId),
    repo.listOpportunities(userId),
    repo.getActiveOpportunity(userId),
    repo.computeValidationReadiness(userId),
    repo.getUserById(userId),
  ]);
  const ideaContext = activeIdea
    ? { title: activeIdea.title, customer: activeIdea.customer, problem: activeIdea.problem, mission: activeIdea.mission }
    : undefined;
  // D-012: proactive, not just a rejection surprise — an Explorer account
  // without a confirmed guardian sees this before trying to save a risky
  // experiment, not after being blocked.
  const isExplorer = user?.ageBand === "explorer";
  const needsGuardian = isExplorer && !(await consent.hasConfirmedGuardianConsent(userId));

  return (
    <div>
      <div className="eyebrow">Customer Street &amp; Pilot Ground · Validation Quest Lab</div>
      <h2 className="font-display text-[26px] mt-1">Experiments</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Every experiment declares a hypothesis, method and threshold before it runs. Completing an activity is not validation — evidence must move a
        claim. Results reflect only what you enter.
      </p>
      {needsGuardian && (
        <div className="mt-3">
          <Notice tone="warn">
            Your account is registered as Explorer (13&ndash;17) with no confirmed guardian yet. You can still add
            experiments here &mdash; only ones involving real money, a contract, or contacting someone you don&apos;t
            know need a guardian confirmed first. <a href="/dashboard/privacy">Add one on Privacy &amp; Consent</a>.
          </Notice>
        </div>
      )}
      <JourneyBar step="validation" activeIdea={activeIdea} opportunityCount={opportunities.length} />

      <Card className="mt-4">
        <ReadinessWidget
          title={`Validation Readiness${activeIdea ? ` — ${activeIdea.title}` : ""}`}
          total={validationReadiness.total}
          dims={validationReadiness.dims}
        />
      </Card>
      {experiments.length === 0 && <Notice>No experiments defined yet.</Notice>}

      <div className="flex flex-col gap-4 mt-5">
        {experiments.map((e) => (
          <Card key={e.id}>
            <div className="flex justify-between gap-2 flex-wrap">
              <h4 className="font-display text-[18px]" style={{ maxWidth: "44ch" }}>{e.name}</h4>
              <div className="flex items-center gap-2">
                <span className={`badge ${e.metThreshold === "yes" ? "badge-green" : e.metThreshold === "no" ? "badge-red" : e.result ? "badge-amber" : "badge-grey"}`}>
                  <span className="dot" />
                  {e.metThreshold === "yes" ? "Threshold met" : e.metThreshold === "no" ? "Threshold not met" : e.result ? "Result recorded — not yet assessed" : "Not yet run"}
                </span>
                <form action={removeExperiment.bind(null, e.id)}><button className="btn btn-ghost btn-sm" type="submit">Remove</button></form>
              </div>
            </div>
            <p className="mt-2" style={{ color: "var(--text-dim)" }}><b>Hypothesis:</b> {e.hypothesis || "—"}</p>
            {e.opportunityId && (
              <p style={{ fontSize: 15, color: "var(--text-faint)" }}>
                Linked to: {opportunities.find((o) => o.id === e.opportunityId)?.title || "an idea that was removed"}
              </p>
            )}
            {(e.involvesMoney || e.involvesContract || e.involvesStrangerContact) && (
              <div className="flex gap-2 flex-wrap mt-2">
                {e.involvesMoney && <span className="badge badge-amber" style={{ fontSize: 11, padding: "2px 7px" }}>Real money</span>}
                {e.involvesContract && <span className="badge badge-amber" style={{ fontSize: 11, padding: "2px 7px" }}>Contract</span>}
                {e.involvesStrangerContact && <span className="badge badge-amber" style={{ fontSize: 11, padding: "2px 7px" }}>Contacting someone new</span>}
              </div>
            )}
            <div className="grid md:grid-cols-3 gap-4 mt-3">
              <div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Method</span><span>{e.method || "—"}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>KPI</span><span>{e.kpi || "—"}</span></div>
              </div>
              <div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Threshold</span><span>{e.threshold || "—"}</span></div>
                <div className="kv-row"><span style={{ color: "var(--text-faint)" }}>Stop rule</span><span>{e.stopRule || "—"}</span></div>
              </div>
              <div>
                <label className="field-label">Result</label>
                <ExperimentResultInput id={e.id} initial={e.result} initialVerdict={e.metThreshold} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <h4 className="font-display text-[18px]">Add an experiment</h4>
        <ValidationForm ideaContext={ideaContext} opportunityId={activeIdea?.id} />
      </Card>
    </div>
  );
}
