import { TREND_CATEGORIES } from "@/lib/trends";
import { Card } from "@/components/ui";
import AddToFitMapButton from "@/components/AddToFitMapButton";
import Link from "next/link";

export default function TrendsPage() {
  return (
    <div>
      <div className="eyebrow">Trend Radar</div>
      <h2 className="font-display text-[26px] mt-1">What Gen Z is building and buying</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Strategic categories with real, sourced examples — context for shaping your own idea, not a rival list. Click{" "}
        <b>+ Add to my Founder Fit Map</b> on a category to carry it straight into your venture categories there.
      </p>

      <div className="grid md:grid-cols-2 gap-4 mt-5">
        {TREND_CATEGORIES.map((c) => (
          <Card key={c.name}>
            <h4 className="font-display text-[17px]">{c.name}</h4>
            <p className="mt-2" style={{ color: "var(--text-dim)" }}>{c.why}</p>
            <div className="mt-3 flex flex-col gap-1">
              {c.examples.map((e) => (
                <p key={e.name} style={{ fontSize: 15, color: "var(--text-faint)" }}>
                  •{" "}
                  <a href={e.url} target="_blank" rel="noopener" style={{ color: "var(--accent)" }}>
                    {e.name}
                  </a>{" "}
                  — {e.what}{" "}
                  {e.src && (
                    <a href={e.src.url} target="_blank" rel="noopener" style={{ color: "var(--text-faint)", fontSize: 13, textDecoration: "underline" }}>
                      ({e.src.label})
                    </a>
                  )}
                </p>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <a href={c.link.url} target="_blank" rel="noopener" className="btn btn-ghost btn-sm">
                {c.link.label} →
              </a>
              {c.link.src && (
                <a href={c.link.src.url} target="_blank" rel="noopener" style={{ color: "var(--text-faint)", fontSize: 13, textDecoration: "underline" }}>
                  Source: {c.link.src.label}
                </a>
              )}
              <div className="flex-1" />
              <AddToFitMapButton name={c.name} />
            </div>
          </Card>
        ))}
      </div>

      <div className="mt-6"><Link href="/dashboard/validation" className="btn btn-primary">Continue to Validation Quest Lab →</Link></div>
    </div>
  );
}
