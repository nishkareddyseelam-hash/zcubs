import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { addRisk, removeRisk } from "@/lib/actions";
import { Card } from "@/components/ui";
import JourneyBar from "@/components/JourneyBar";
import PassportClaims from "@/components/PassportClaims";
import ScoreRing from "@/components/ScoreRing";
import Link from "next/link";

function recommendation(total: number) {
  if (total < 25) return "Not enough of this workspace is filled in yet to make a recommendation. Start with Self Discovery and one Opportunity Card.";
  if (total < 50) return "Early stage — continue gathering evidence before making a proceed/pivot decision. Regulatory readiness and validation quality are likely your biggest gaps.";
  if (total < 75) return "Building a real case, but key assumptions remain untested. Proceed to your next validation mission before increasing spend.";
  return "Strong evidence coverage for this workspace. Still a decision-support signal, not a guarantee — review the components above before committing capital.";
}

// Where to go to actually move each readiness dimension — makes the score
// a set of connected next actions, not just a static report.
const DIM_LINKS: Record<string, { href: string; label: string }> = {
  fit: { href: "/dashboard/fitmap", label: "Self Discovery" },
  problem: { href: "/dashboard/opportunities", label: "Opportunity Forest" },
  customer: { href: "/dashboard/validation", label: "Validation Quest Lab" },
  validation: { href: "/dashboard/validation", label: "Validation Quest Lab" },
  market: { href: "/dashboard/evidence", label: "Evidence Lab" },
  unit: { href: "/dashboard/money", label: "Money Lab" },
  capital: { href: "/dashboard/money", label: "Money Lab" },
};

export default async function PassportPage() {
  const userId = await requireUserId();
  const claims = await repo.listEvidence(userId);
  const risks = await repo.listRisks(userId);
  const experiments = await repo.listExperiments(userId);
  const { total, dims } = await repo.computeReadiness(userId);
  const opportunities = await repo.listOpportunities(userId);
  const activeIdea = await repo.getActiveOpportunity(userId);
  const activeExperiments = activeIdea ? experiments.filter((e) => e.opportunityId === activeIdea.id) : [];
  const activeClaims = activeIdea ? claims.filter((c) => c.opportunityId === activeIdea.id) : [];

  return (
    <div>
      <div className="eyebrow">Risk Fortress · Venture Evidence Passport</div>
      <h2 className="font-display text-[26px] mt-1">Evidence Passport</h2>
      <p className="mt-2" style={{ color: "var(--text-dim)", maxWidth: "66ch" }}>
        Not a certification, regulatory approval, or a guarantee of funding — a living record of exactly what you&apos;ve entered.
      </p>
      <JourneyBar step="passport" activeIdea={activeIdea} opportunityCount={opportunities.length} />

      {activeIdea && (
        <Card className="mt-5">
          <h4 className="font-display text-[18px]">Where &quot;{activeIdea.title}&quot; stands</h4>
          <div className="grid md:grid-cols-3 gap-4 mt-3">
            <div>
              <div className="eyebrow">Evidence linked</div>
              <div className="font-display text-[22px] mt-1">{activeClaims.length} item{activeClaims.length === 1 ? "" : "s"}</div>
            </div>
            <div>
              <div className="eyebrow">Experiments linked</div>
              <div className="font-display text-[22px] mt-1">
                {activeExperiments.length} ({activeExperiments.filter((e) => e.metThreshold === "yes").length} met threshold)
              </div>
            </div>
            <div>
              <div className="eyebrow">Next step</div>
              <div className="mt-1">
                {activeExperiments.length === 0 ? (
                  <Link href="/dashboard/validation" className="btn btn-ghost btn-sm">Define an experiment →</Link>
                ) : activeClaims.length === 0 ? (
                  <Link href="/dashboard/evidence" className="btn btn-ghost btn-sm">Log evidence →</Link>
                ) : (
                  <Link href="/dashboard/money" className="btn btn-ghost btn-sm">Review Money Lab →</Link>
                )}
              </div>
            </div>
          </div>
        </Card>
      )}

      <Card className="mt-5">
        <h4 className="font-display text-[18px]">Claims &amp; evidence quality</h4>
        <PassportClaims
          claims={JSON.parse(JSON.stringify(claims))}
          opportunities={JSON.parse(JSON.stringify(opportunities))}
          activeIdea={activeIdea ? JSON.parse(JSON.stringify(activeIdea)) : undefined}
        />
      </Card>

      <div className="grid md:grid-cols-2 gap-4 mt-5">
        <Card>
          <h4 className="font-display text-[18px]">Risk register</h4>
          {risks.length === 0 ? (
            <p className="mt-2" style={{ color: "var(--text-faint)" }}>No risks logged yet.</p>
          ) : (
            <div className="mt-3 flex flex-col gap-3">
              {risks.map((r) => (
                <div key={r.id}>
                  <div className="flex justify-between items-start gap-2">
                    <b style={{ fontSize: 18 }}>{r.risk}</b>
                    <div className="flex items-center gap-2">
                      <span className={`badge ${r.severity === "High" ? "badge-red" : r.severity === "Medium" ? "badge-amber" : "badge-grey"}`}><span className="dot" />{r.severity}</span>
                      <form action={removeRisk.bind(null, r.id)}><button className="btn btn-ghost btn-sm" type="submit">✕</button></form>
                    </div>
                  </div>
                  <p style={{ color: "var(--text-faint)" }}>{r.mitigation}</p>
                </div>
              ))}
            </div>
          )}
          <form action={addRisk} className="mt-4 flex flex-col gap-2">
            <input name="risk" required className="field-input" placeholder="Risk" />
            <input name="mitigation" className="field-input" placeholder="Mitigation" />
            <select name="severity" className="field-input" defaultValue="Medium"><option>Low</option><option>Medium</option><option>High</option></select>
            <button className="btn btn-ghost btn-sm" type="submit">Add risk</button>
          </form>
        </Card>
        <Card>
          <h4 className="font-display text-[18px]">Venture Readiness Score</h4>
          <div className="flex items-center gap-4 mt-2 flex-wrap">
            <ScoreRing value={total} size={92} />
            <span style={{ color: "var(--text-faint)", fontSize: 16, maxWidth: "32ch" }}>weighted composite of the dimensions below — not a success probability</span>
          </div>
          <div className="mt-4 flex flex-col gap-2.5">
            {dims.map((d) => {
              const link = DIM_LINKS[d.k];
              return (
                <div key={d.k}>
                  <div className="flex justify-between" style={{ fontSize: 16 }}><span>{d.label} <span className="font-mono-plex" style={{ color: "var(--text-faint)" }}>×{d.w}</span></span><span className="font-mono-plex">{d.v}%</span></div>
                  <div className="progress-track mt-1"><div className="progress-fill" style={{ width: `${d.v}%` }} /></div>
                  <p style={{ fontSize: 15, color: "var(--text-faint)" }}>
                    {d.why}
                    {link && d.v < 100 && (
                      <> <Link href={link.href} style={{ color: "var(--accent)" }}>Go to {link.label} →</Link></>
                    )}
                  </p>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      <div className="notice notice-good mt-5"><b>Current recommendation:</b> {recommendation(total)}</div>
      <div className="flex gap-3 mt-5">
        <Link href="/dashboard/launch" className="btn btn-primary">Continue to India Launch Pack →</Link>
      </div>
    </div>
  );
}
