import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { Card, Notice } from "@/components/ui";
import ProductTour from "@/components/ProductTour";

export default async function LandingPage() {
  const session = await getServerSession(authOptions);
  if (session) redirect("/dashboard");

  return (
    <main className="min-h-screen" style={{ background: "var(--bg)" }}>
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="flex items-center gap-2 font-display font-semibold text-[20px]">
          <span
            className="w-8 h-8 rounded-lg grid place-items-center text-white font-display font-bold"
            style={{ background: "linear-gradient(135deg, #4a41e0, #1c9b8e)" }}
          >
            Z
          </span>
          Z Cubs
        </div>

        <section className="pt-16 pb-10" style={{ position: "relative", overflow: "hidden" }}>
          <div
            aria-hidden="true"
            style={{
              position: "absolute", width: 380, height: 380, borderRadius: "50%",
              background: "var(--accent)", top: -180, right: -60, filter: "blur(60px)", opacity: 0.35, pointerEvents: "none",
            }}
          />
          <div
            aria-hidden="true"
            style={{
              position: "absolute", width: 280, height: 280, borderRadius: "50%",
              background: "var(--spark)", top: 60, right: 240, filter: "blur(60px)", opacity: 0.25, pointerEvents: "none",
            }}
          />
          <div style={{ position: "relative" }}>
            <div className="eyebrow">India&apos;s evidence-led Founder Operating System</div>
            <h1 className="mt-2 font-display" style={{ fontSize: "clamp(32px,5vw,52px)", lineHeight: 1.08, maxWidth: "16ch" }}>
              From curiosity to credible venture.
            </h1>
            <p className="mt-4" style={{ color: "var(--text-dim)", fontSize: 20, maxWidth: "58ch" }}>
              A working founder workspace — real accounts, a real database, your own evidence and inputs.
              Every claim is traceable to a source or clearly labelled as an assumption. Nothing here is fabricated on your behalf.
            </p>
            <div className="flex gap-3 mt-8">
              <Link href="/signup" className="btn btn-primary">Create your account</Link>
              <Link href="/login" className="btn btn-ghost">Log in</Link>
            </div>
          </div>
        </section>

        <section className="pb-6" aria-label="Product tour">
          <ProductTour />
        </section>

        <Notice>
          This is a working, self-hosted application: your own sign-in, a real database on this machine, and a full end-to-end journey from
          Self Discovery through Opportunity Cards, Idea Arena, Evidence Register, Validation experiments, Money Lab and the Evidence Passport.
        </Notice>

        <div className="grid md:grid-cols-3 gap-4 mt-8">
          <Card>
            <h3 className="text-[20px] font-display">Self Discovery</h3>
            <p className="mt-2" style={{ color: "var(--text-dim)" }}>Your Founder Fit Map, generated only from what you enter.</p>
          </Card>
          <Card>
            <h3 className="text-[20px] font-display">Evidence-governed</h3>
            <p className="mt-2" style={{ color: "var(--text-dim)" }}>Real, cited reference data plus your own sourced evidence register.</p>
          </Card>
          <Card>
            <h3 className="text-[20px] font-display">Money Lab</h3>
            <p className="mt-2" style={{ color: "var(--text-dim)" }}>Driver-based scenario modelling — every assumption is yours to set.</p>
          </Card>
        </div>

        <footer className="mt-16 pt-6 border-t text-[16px]" style={{ borderColor: "var(--line)", color: "var(--text-faint)" }}>
          Z Cubs provides business education and decision support. It does not guarantee financial returns, business success, funding,
          legal compliance or investor acceptance, and does not replace legal, tax, accounting or investment professionals.
        </footer>
      </div>
    </main>
  );
}
