"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", ageBand: "founder" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong.");
        setLoading(false);
        return;
      }
      const signInRes = await signIn("credentials", { redirect: false, email: form.email, password: form.password });
      if (signInRes?.ok) router.push("/dashboard");
      else setError("Account created — please log in.");
    } catch {
      setError("Could not reach the server. Try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
      <div className="card pad w-full max-w-md">
        <div className="eyebrow">Create your account</div>
        <h1 className="font-display text-[26px] mt-1">Start your Founder OS workspace</h1>
        <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-4">
          <div>
            <label className="field-label">Full name</label>
            <input className="field-input" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="field-label">Email</label>
            <input type="email" className="field-input" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="field-label">Password (min 8 characters)</label>
            <input type="password" minLength={8} className="field-input" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          <div>
            <label className="field-label">Age band</label>
            <select className="field-input" value={form.ageBand} onChange={(e) => setForm({ ...form, ageBand: e.target.value })}>
              <option value="explorer">Explorer (13–17, guardian/school-supported)</option>
              <option value="founder">Founder (18–28)</option>
              <option value="institution">Institution admin</option>
            </select>
          </div>
          {error && <p style={{ color: "var(--bad)", fontSize: 18 }}>{error}</p>}
          <button type="submit" disabled={loading} className="btn btn-primary justify-center">
            {loading ? "Creating account…" : "Create account"}
          </button>
        </form>
        <p className="mt-5 text-center" style={{ color: "var(--text-faint)" }}>
          Already have an account? <Link href="/login" style={{ color: "var(--accent)" }}>Log in</Link>
        </p>
      </div>
    </main>
  );
}
