import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { createUser, getUserByEmail } from "@/lib/repo";

const SignupSchema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  password: z.string().min(8).max(200),
  ageBand: z.enum(["explorer", "founder", "institution"]),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = SignupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check your name, email, password (min 8 characters) and role." }, { status: 400 });
  }
  const { name, email, password, ageBand } = parsed.data;
  const normalizedEmail = email.toLowerCase().trim();
  if (await getUserByEmail(normalizedEmail)) {
    return NextResponse.json({ error: "An account with that email already exists. Try logging in instead." }, { status: 409 });
  }
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await createUser({ name: name.trim(), email: normalizedEmail, passwordHash, ageBand });
  return NextResponse.json({ ok: true, id: user.id });
}
