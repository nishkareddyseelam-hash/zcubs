import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { resolveTemplateSeedServer } from "@/lib/guideContext";

/**
 * The Guide-landing "name your business" prompt for a founder who opened
 * the Guide directly (nav rail / home hero button) rather than through a
 * home-page template tile — so the Guide never sits blank waiting for a
 * trip to Trend Radar first. Picks a real seed the same way the template
 * flow does (profile-matched sourced sector if one fits, otherwise a
 * generic honestly-labelled pattern), saves it to guide_meta, and lets
 * every step lazily draft itself from there as the founder visits it.
 */
export async function POST(req: Request) {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  let body: { businessName?: string; notes?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const businessName = (body.businessName || "").trim();
  if (!businessName) return NextResponse.json({ error: "businessName is required" }, { status: 400 });
  const notes = (body.notes || "").trim();

  const profile = await repo.getFounderProfile(userId);
  const profileCtx: Record<string, string> = profile ? { strengths: profile.strengths, categories: profile.categories } : {};
  const { customer, problem, mission, templateLabel } = resolveTemplateSeedServer(profileCtx);

  await repo.saveGuideMeta(userId, { businessName, templateLabel: templateLabel || "", notes, customer, problem, mission });
  return NextResponse.json({ ok: true });
}
