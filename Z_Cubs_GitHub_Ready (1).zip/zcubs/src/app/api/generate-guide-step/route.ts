import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { findStep } from "@/lib/guideStructure";
import { buildGuideDraftContext } from "@/lib/guideContext";
import { populateStepContent } from "@/lib/guideStepPopulate";

/**
 * The "live effect" — called once, client-side, the moment a founder opens
 * a Guide step that has no content yet. Uses whatever real context already
 * exists (active Opportunity Card, or the business name/seed saved in
 * guide_meta from a template or the "name your business" prompt) to draft
 * that one step's fields/items/SWOT, the same way generate-guide-all does
 * for a full template start. Returns `needsContext: true` — without
 * generating anything — when neither exists yet, so the client can prompt
 * for a business name instead of silently doing nothing.
 */
export async function POST(req: Request) {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  let body: { chapterId?: string; stepId?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const found = body.chapterId && body.stepId ? findStep(body.chapterId, body.stepId) : null;
  if (!found) return NextResponse.json({ error: "Unknown step" }, { status: 404 });

  const activeIdea = await repo.getActiveOpportunity(userId);
  const meta = await repo.getGuideMeta(userId);
  if (!activeIdea && !meta.businessName) {
    return NextResponse.json({ ok: false, needsContext: true });
  }

  const ctx = buildGuideDraftContext(meta, activeIdea ? { title: activeIdea.title, customer: activeIdea.customer, problem: activeIdea.problem } : undefined);
  const touched = await populateStepContent(userId, found.step, ctx);
  return NextResponse.json({ ok: true, touched });
}
