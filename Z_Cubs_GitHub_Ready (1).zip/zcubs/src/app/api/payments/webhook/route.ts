import { NextResponse } from "next/server";
import { verifyWebhookSignature, handleWebhookEvent } from "@/lib/payments";

// Razorpay webhook receiver (D-020, docs/DECISION_LOG.md) — the ONLY
// place a plan purchase actually upgrades a user's plan. Deliberately
// unauthenticated (Razorpay calls this server-to-server; there is no
// user session) — the HMAC signature check against RAZORPAY_WEBHOOK_SECRET
// is what authenticates the caller instead. Configure this URL
// (https://<your-domain>/api/payments/webhook) in the Razorpay dashboard
// under Settings > Webhooks, subscribed to at least "payment.captured"
// and "payment.failed" — see docs/DEPLOYMENT.md.
export async function POST(req: Request) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-razorpay-signature") ?? "";

  if (!verifyWebhookSignature(rawBody, signature)) {
    // Deliberately vague — never confirm/deny which part of the check
    // failed to an unauthenticated caller.
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const event = JSON.parse(rawBody);
  const result = await handleWebhookEvent(event);
  // Always 200 once the signature is valid and we've looked at the event
  // — Razorpay retries on non-2xx, and retrying an event we deliberately
  // ignored (e.g. an event type we don't act on) would just repeat
  // forever for no benefit.
  return NextResponse.json({ ok: true, ...result });
}
