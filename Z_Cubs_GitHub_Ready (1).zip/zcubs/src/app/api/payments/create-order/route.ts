import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/session";
import { createPlanOrder, RAZORPAY_ENABLED } from "@/lib/payments";

// Creates a real Razorpay order for a self-serve plan purchase (D-020,
// docs/DECISION_LOG.md). This endpoint only ever CREATES an unpaid order
// record — it never upgrades anyone's plan. See src/lib/payments.ts for
// why: only the signature-verified webhook does that.
export async function POST(req: Request) {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  if (!RAZORPAY_ENABLED) {
    return NextResponse.json({ error: "Payments are not configured on this deployment yet." }, { status: 503 });
  }

  const body = await req.json().catch(() => null);
  const plan = body?.plan;
  if (typeof plan !== "string") {
    return NextResponse.json({ error: "Missing plan." }, { status: 400 });
  }

  try {
    const { purchase, keyId } = await createPlanOrder(userId, plan);
    return NextResponse.json({
      orderId: purchase.razorpayOrderId,
      amountPaise: purchase.amountPaise,
      currency: purchase.currency,
      keyId,
    });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Could not create order." }, { status: 400 });
  }
}
