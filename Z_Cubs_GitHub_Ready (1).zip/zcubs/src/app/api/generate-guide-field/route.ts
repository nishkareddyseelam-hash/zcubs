import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/session";
import { findStep } from "@/lib/guideStructure";
import { draftGuideFieldText } from "@/lib/guideAutoDraft";
import { buildGuideDraftContext } from "@/lib/guideContext";
import * as repo from "@/lib/repo";

/**
 * Drafts ONE narrative field inside a Guide step — the single-field
 * "✨ Draft for me" button (used to regenerate a field the founder isn't
 * happy with). Shares its actual drafting logic with the bulk/lazy flows
 * (see guideAutoDraft.ts / guideStepPopulate.ts) so all three behave
 * identically. Context prefers, in order: the founder's active Opportunity
 * Card, then the business name/seed captured in guide_meta (from a
 * template or the "name your business" prompt), then honest bracketed
 * placeholders — never a fabricated fact either way.
 */
export async function POST(req: Request) {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  let body: { chapterId?: string; stepId?: string; fieldKey?: string; fieldLabel?: string; opportunity?: { title?: string; customer?: string; problem?: string }; profile?: Record<string, string>; stepContext?: Record<string, string> };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const found = body.chapterId && body.stepId ? findStep(body.chapterId, body.stepId) : null;
  const fieldKey = body.fieldKey || "";
  const field = found?.step.fields.find((f) => f.key === fieldKey) || { key: fieldKey, label: body.fieldLabel || "this field", hint: "" };

  const meta = await repo.getGuideMeta(userId);
  const opp = body.opportunity && (body.opportunity.title || body.opportunity.customer || body.opportunity.problem) ? body.opportunity : undefined;
  const base = buildGuideDraftContext(meta, opp);

  const { text, source } = await draftGuideFieldText(userId, found?.step || null, field, {
    ...base,
    profile: body.profile || {},
    stepContext: body.stepContext || {},
  });

  return NextResponse.json({ text, source });
}
