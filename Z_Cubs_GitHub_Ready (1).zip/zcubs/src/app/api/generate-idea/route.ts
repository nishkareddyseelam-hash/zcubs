import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { AI_ENABLED, callClaudeForUser, parseJsonObject } from "@/lib/aiClient";
import { CURATED_IDEA_SEEDS, CURATED_SUGGESTIONS } from "@/lib/suggestData";
import { matchTrendCategories, ideaSeedFromTrend, TREND_CATEGORIES } from "@/lib/trends";
import { getActiveInsightExamples } from "@/lib/insights";

/**
 * Generates a DRAFT Opportunity Card the founder reviews and edits before
 * saving — nothing here is auto-submitted. This is ideation, not evidence:
 * the generated "problem" and "customer" are plausible starting hypotheses
 * for the founder to go verify, never presented as researched fact. The
 * generated evidenceNote is always empty and evidenceClass is always
 * "assumption", regardless of what the model returns, so a generated card
 * can never masquerade as evidenced.
 */
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  let body: { category?: string; pattern?: string; profile?: Record<string, string> };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const category = String(body.category || "").trim();
  const pattern = String(body.pattern || "").trim();
  const profile = body.profile && typeof body.profile === "object" ? body.profile : {};

  const fields = ["title", "customer", "problem", "mission"];

  // Real signal #0: a "ready to click" template on the home page — the founder
  // picked a specific sourced sector tile themselves, so it takes priority over
  // any inferred profile match below.
  const explicitTrend = category ? TREND_CATEGORIES.find((c) => c.name === category) || null : null;

  // Real signal #1: match the founder's own stated profile text against the
  // sourced, cited sector trends already shown on Trend Radar — never a
  // fabricated fact about their specific venture, just real category-level
  // context they can go verify.
  const trendMatches = matchTrendCategories(profile as { categories?: string; strengths?: string });
  const bestTrend = explicitTrend || (trendMatches.length ? trendMatches[Math.floor(Math.random() * Math.min(2, trendMatches.length))] : null);

  if (AI_ENABLED) {
    const profileLines = Object.entries(profile)
      .filter(([, v]) => (v || "").trim().length > 0)
      .map(([k, v]) => `${k}: ${v}`)
      .join("\n");
    const system = [
      "You draft a starting Opportunity Card for a first-time Gen Z founder in India using an evidence-governed founder-education product.",
      "Reply with ONLY a JSON object with exactly these string keys: title, customer, problem, mission. No prose, no markdown outside the JSON.",
      "title: a short venture idea name (under 60 chars). customer: a specific target customer segment. problem: the problem this idea addresses, phrased as a hypothesis to go verify, not as a proven fact.",
      "mission: one concrete, small first validation action the founder could take this week.",
      "Never state specific numbers, market sizes, or claims about real companies as fact — this is ideation, not evidence.",
    ].join(" ");
    const patternSeed = pattern ? CURATED_IDEA_SEEDS.find((s) => s.id === pattern) : null;
    // D-021 (docs/DECISION_LOG.md): real, human-approved examples from other
    // founders' own opportunity cards, when any exist — reference material
    // only, so this draft leans on real Gen Z founder patterns rather than
    // generic advice. Empty (never fabricated filler) until an admin has
    // approved at least one.
    const insightExamples = await getActiveInsightExamples("idea_generation", 2);
    const userPrompt = [
      category ? `Trend/sector to draw on: ${category}` : bestTrend ? `Trend/sector matched from the founder's own profile: ${bestTrend.name} — ${bestTrend.why}` : "No specific sector requested — draw on the founder's own profile below.",
      patternSeed ? `The founder clicked a "${patternSeed.label}" starting pattern — shape the idea as that kind of venture (e.g. ${patternSeed.title}).` : "",
      profileLines ? `Founder's Self Discovery profile:\n${profileLines}` : "No founder profile on file yet.",
      insightExamples.length
        ? `For tone and style only, here are real (anonymized, human-reviewed) examples of ideas other founders on this platform have worked on — do NOT copy them, draft something new and specific to this founder:\n${insightExamples.map((e) => `- ${e}`).join("\n")}`
        : "",
      "Draft one plausible, specific Opportunity Card as JSON.",
    ].filter(Boolean).join("\n\n");
    const userId = (session.user as { id?: string }).id as string;
    const reply = await callClaudeForUser(userId, "idea", system, userPrompt, { maxTokens: 400 });
    const parsed = parseJsonObject(reply, fields);
    if (parsed && parsed.title) {
      return NextResponse.json({ idea: parsed, source: "ai" });
    }
  }

  // Non-AI path: if the founder's own profile text matches a sourced sector
  // trend, draft from that real, cited context instead of a generic
  // template. Otherwise fall back to the generic, honestly-labelled seeds.
  if (bestTrend) {
    const seed = ideaSeedFromTrend(bestTrend, profile as { strengths?: string });
    const customerOptions = CURATED_SUGGESTIONS["opportunities.customer"] || [];
    const customer = customerOptions[Math.floor(Math.random() * customerOptions.length)] || "";
    return NextResponse.json({
      idea: { title: seed.title, customer, problem: seed.problem, mission: seed.mission },
      source: "trend",
      trendName: seed.trendName,
    });
  }

  const seed = (pattern && CURATED_IDEA_SEEDS.find((s) => s.id === pattern)) || CURATED_IDEA_SEEDS[Math.floor(Math.random() * CURATED_IDEA_SEEDS.length)];
  return NextResponse.json({
    idea: {
      title: category ? `${category}: ${seed.title}` : seed.title,
      customer: seed.customer,
      problem: seed.problem,
      mission: seed.mission,
    },
    source: "curated",
  });
}
