import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/session";
import * as consent from "@/lib/consent";

// Real "right to access" export (D-010, docs/DECISION_LOG.md) — self only,
// live query at request time, no cached/stale copy. Files the originating
// data_requests row (if any) as completed the moment the export is
// actually produced, so "pending" never silently means "already sent".
export async function GET(req: Request) {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }
  const url = new URL(req.url);
  const requestId = url.searchParams.get("requestId") ?? undefined;

  const data = await consent.exportUserData(userId, requestId);
  const json = JSON.stringify(data, null, 2);
  return new NextResponse(json, {
    status: 200,
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="zcubs-my-data-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}
