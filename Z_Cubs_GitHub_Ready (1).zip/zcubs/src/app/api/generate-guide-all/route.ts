import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/session";
import * as repo from "@/lib/repo";
import { GUIDE_CHAPTERS } from "@/lib/guideStructure";
import { resolveTemplateSeedServer, buildGuideDraftContext } from "@/lib/guideContext";
import { populateStepContent } from "@/lib/guideStepPopulate";

/**
 * The home-page "ready to click" template flow, once the founder has named
 * the business and chosen "Open the step-by-step Guide": resolves one real
 * seed (sourced Trend Radar sector, or a generic honestly-labelled
 * pattern), saves it to guide_meta so every later lazily-generated step
 * stays consistent, then drafts every AI-eligible narrative field PLUS
 * item-list and SWOT suggestions across all 4 chapters / 20 steps in one
 * pass (see guideStepPopulate.ts) — so the whole Guide already has
 * something concrete to review, edit, or remove instead of a blank "add
 * one yourself" box. Never overwrites a field/list the founder already
 * filled in.
 */
export async function POST(req: Request) {
  let userId: string;
  try {
    userId = await requireUserId();
  } catch {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  let body: { businessName?: string; category?: string; pattern?: string; notes?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const businessName = (body.businessName || "").trim();
  if (!businessName) return NextResponse.json({ error: "businessName is required" }, { status: 400 });
  const category = (body.category || "").trim();
  const pattern = (body.pattern || "").trim();
  const notes = (body.notes || "").trim();

  const profile = await repo.getFounderProfile(userId);
  const profileCtx: Record<string, string> = profile ? { strengths: profile.strengths, categories: profile.categories } : {};

  const { customer, problem, mission, templateLabel } = resolveTemplateSeedServer(profileCtx, category, pattern);

  const meta: repo.GuideMeta = { businessName, templateLabel: templateLabel || "", notes, customer, problem, mission };
  await repo.saveGuideMeta(userId, meta);
  const ctx = buildGuideDraftContext(meta);

  let stepsTouched = 0;
  for (const chapter of GUIDE_CHAPTERS) {
    for (const step of chapter.steps) {
      const touched = await populateStepContent(userId, step, ctx);
      if (touched) stepsTouched++;
    }
  }

  return NextResponse.json({ ok: true, stepsTouched });
}
