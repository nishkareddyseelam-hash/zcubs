import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { AI_ENABLED, callClaudeForUser, parseStringArray } from "@/lib/aiClient";
import { getCuratedSuggestions } from "@/lib/suggestData";
import { TREND_CATEGORY_NAMES } from "@/lib/trends";

/**
 * Live, context-aware suggestions for a single form field. Requires a
 * signed-in session (this calls a paid external API when a key is
 * configured, and it's workspace-specific input, not public data).
 *
 * Response shape: { suggestions: string[], source: "ai" | "curated" }
 * `source` is surfaced so the UI can be honest about which one produced
 * the list, rather than implying "AI" when it's really the static list.
 */
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  let body: { field?: string; context?: Record<string, string> };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const field = String(body.field || "");
  const context = body.context && typeof body.context === "object" ? body.context : {};
  if (!field) return NextResponse.json({ error: "field is required" }, { status: 400 });

  const curated = getCuratedSuggestions(field);
  // The venture-categories field always includes the real, sourced Trend
  // Radar sector names, regardless of AI availability — this is what makes
  // "click a sector, it shows up here" actually true end to end.
  const baseList = field === "fitmap.categories" ? Array.from(new Set([...curated, ...TREND_CATEGORY_NAMES])) : curated;

  if (!AI_ENABLED) {
    return NextResponse.json({ suggestions: baseList, source: "curated" });
  }

  const contextLines = Object.entries(context)
    .filter(([, v]) => (v || "").trim().length > 0)
    .map(([k, v]) => `${k}: ${v}`)
    .join("\n");

  const system = [
    "You generate short dropdown-suggestion options for a founder-education product used by young, first-time entrepreneurs in India.",
    "Reply with ONLY a JSON array of 6-8 short strings (each under 70 characters). No prose, no markdown, no explanation — just the JSON array.",
    "Suggestions must be realistic, specific, and genuinely useful as pre-filled options a first-time founder could pick or adapt — never generic filler like 'Option 1'.",
    "Never invent specific numbers, company names, or claims presented as fact about the founder's own venture — these are option prompts, not assertions.",
  ].join(" ");

  const userPrompt = [
    `Field: ${field}`,
    contextLines ? `What the founder has already entered elsewhere in this form:\n${contextLines}` : "No other context entered yet.",
    curated.length ? `Some starting ideas already on file for this field: ${curated.slice(0, 5).join(", ")}` : "",
    "Generate 6-8 short suggested options for this specific field, tailored to the context above where relevant.",
  ]
    .filter(Boolean)
    .join("\n\n");

  const userId = (session.user as { id?: string }).id as string;
  const reply = await callClaudeForUser(userId, "suggest", system, userPrompt, { maxTokens: 400 });
  const parsed = parseStringArray(reply, 8);

  if (!parsed || parsed.length === 0) {
    return NextResponse.json({ suggestions: baseList, source: "curated" });
  }
  // For categories, still fold in the real sourced trend names even when AI
  // is answering, so the Trend Radar link stays truthful either way.
  const suggestions = field === "fitmap.categories" ? Array.from(new Set([...parsed, ...TREND_CATEGORY_NAMES])) : parsed;
  return NextResponse.json({ suggestions, source: "ai" });
}
