"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await signIn("credentials", { redirect: false, email, password });
    setLoading(false);
    if (res?.ok) router.push("/dashboard");
    else setError("Incorrect email or password.");
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--bg)" }}>
      <div className="card pad w-full max-w-md">
        <div className="eyebrow">Welcome back</div>
        <h1 className="font-display text-[26px] mt-1">Log in to Z Cubs</h1>
        <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-4">
          <div>
            <label className="field-label">Email</label>
            <input type="email" className="field-input" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="field-label">Password</label>
            <input type="password" className="field-input" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {error && <p style={{ color: "var(--bad)", fontSize: 18 }}>{error}</p>}
          <button type="submit" disabled={loading} className="btn btn-primary justify-center">
            {loading ? "Logging in…" : "Log in"}
          </button>
        </form>
        <p className="mt-5 text-center" style={{ color: "var(--text-faint)" }}>
          New here? <Link href="/signup" style={{ color: "var(--accent)" }}>Create an account</Link>
        </p>
      </div>
    </main>
  );
}
